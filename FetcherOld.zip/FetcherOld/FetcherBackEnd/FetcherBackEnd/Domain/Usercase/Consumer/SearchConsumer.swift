//
//  SearchConsumer.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 24/02/23.
//

import Foundation
import VTComponents


public final class SearchConsumerRequest: ZRequest {
    public var columnName: String
    public var columnType: Any
    public init(columnName: String, columnType: Any) {
        self.columnName = columnName
        self.columnType = columnType
        super.init(zuid: " ")
    }
}

public final class SearchConsumerResponse: ZResponse {
    public var consumer: [Consumer]
    public init(consumer: [Consumer]) {
        self.consumer = consumer
    }
}

public final class SearchConsumerError: ZError {
    
}

public final class SearchConsumer: ZUsecase<SearchConsumerRequest, SearchConsumerResponse, SearchConsumerError> {
    var dataManager: SearchConsumerDataContract
    public var searchConsumerResponse: SearchConsumerResponse?
    public var searchConsumerError: SearchConsumerError?
    public init(dataManager: SearchConsumerDataContract) {
        self.dataManager = dataManager
    }
    
    public override func run(request: SearchConsumerRequest, success: @escaping (SearchConsumerResponse) -> Void, failure: @escaping (SearchConsumerError) -> Void) {
//        print("Search Consumer usecase")
        dataManager.searchConsumer(success: { [weak self] (consumer) in
            self?.success(consumer: consumer, callback: success)
        }, failure: { [weak self] (error) in
            self?.failure(error: error, callback: failure)
        })
    }
    
    private func success(consumer: [Consumer], callback: @escaping (SearchConsumerResponse) -> Void) {
        let response = SearchConsumerResponse(consumer: consumer)
        self.searchConsumerResponse = response
        invokeSuccess(callback: callback, response: response)
    }
    
    private func failure(error: SearchConsumerError, callback: @escaping (SearchConsumerError) -> Void) {
        self.searchConsumerError = error
        invokeFailure(callback: callback, failure: error)
    }
}
