//
//  GetConsumer.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 13/03/23.
//

import Foundation
import VTComponents

public final class GetConsumerListRequest: ZRequest {
    
    public init() {
        super.init(zuid: " ")
    }
}

public final class GetConsumerListResponse: ZResponse {
    public var consumer: [Consumer]
    public init(consumer: [Consumer]) {
        self.consumer = consumer
    }
}

public final class GetConsumerListError: ZError {
    
}

public final class GetConsumerList: ZUsecase<GetConsumerListRequest, GetConsumerListResponse, GetConsumerListError> {
    var dataManager: GetConsumerListDataContract
    public var response: GetConsumerListResponse?
    public var error: GetConsumerListError?
    
    public init(dataManager: GetConsumerListDataContract) {
        self.dataManager = dataManager
    }
    
    public override func run(request: GetConsumerListRequest, success: @escaping (GetConsumerListResponse) -> Void, failure: @escaping (GetConsumerListError) -> Void) {
        dataManager.getConsumerList(success: { [weak self] (consumer) in
            self?.success(consumer: consumer, callback: success)
        }, failure: { [weak self] (error) in
            self?.failure(error: error, callback: failure)
        })
    }
    
    private func success(consumer: [Consumer], callback: @escaping (GetConsumerListResponse) -> Void) {
        self.response = GetConsumerListResponse(consumer: consumer)
        invokeSuccess(callback: callback, response: self.response!)
    }

    private func failure(error: GetConsumerListError, callback: @escaping (GetConsumerListError) -> Void) {
        self.error = error
        invokeFailure(callback: callback, failure: error)
    }
}


