//
//  AddConsumer.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 22/02/23.
//

import Foundation
import VTComponents

public final class AddConsumerRequest: ZRequest {
    var consumer: Consumer
    public init(consumer: Consumer) {
        self.consumer = consumer
        super.init(zuid: " ")
    }
}

public final class AddConsumerResponse: ZResponse {
    public override init() {
        
    }
}

public final class AddConsumerError: ZError {
    
}

public final class AddConsumer: ZUsecase<AddConsumerRequest, AddConsumerResponse, AddConsumerError> {
    var dataManager: AddConsumerDataContract
    public var response: AddConsumerResponse?
    public var error: AddConsumerError?
    
    public init(dataManager: AddConsumerDataContract) {
        self.dataManager = dataManager
    }
    
    public override func run(request: AddConsumerRequest, success: @escaping (AddConsumerResponse) -> Void, failure: @escaping (AddConsumerError) -> Void) {
        dataManager.addConsumer(consumer: request.consumer, success: { [weak self] () in
            self?.success(callback: success)
            
        }, failure: { [weak self] (error) in
            self?.failure(error: error, callback: failure)
            
        })
    }
    
    private func success(callback: @escaping (AddConsumerResponse) -> Void) {
        self.response = AddConsumerResponse()
        invokeSuccess(callback: callback, response: self.response!)
    }
    
    private func failure(error: AddConsumerError, callback: @escaping (AddConsumerError) -> Void) {
        self.error = error
        invokeFailure(callback: callback, failure: error)
    }
}
