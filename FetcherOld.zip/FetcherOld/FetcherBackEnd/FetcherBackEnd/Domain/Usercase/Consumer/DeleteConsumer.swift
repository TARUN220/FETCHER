//
//  DeleteConsumer.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 13/03/23.
//

import Foundation
import VTComponents

public final class DeleteConsumerRequest: ZRequest {
    
    var consumerId: Int
    public init(consumerId: Int) {
        self.consumerId = consumerId
        super.init(zuid: " ")
    }
}
public final class DeleteConsumerResponse: ZResponse {

    public override init() {
        
    }
}

public final class DeleteConsumerError: ZError {
    
}

public final class DeleteConsumer: ZUsecase<DeleteConsumerRequest, DeleteConsumerResponse, DeleteConsumerError> {
    var dataManager: DeleteConsumerDataContract
    public var response: DeleteConsumerResponse?
    public var error: DeleteConsumerError?
    
    public init(dataManager: DeleteConsumerDataContract) {
        self.dataManager = dataManager
    }
    
    public override func run(request: DeleteConsumerRequest, success: @escaping (DeleteConsumerResponse) -> Void, failure: @escaping (DeleteConsumerError) -> Void) {
        dataManager.deleteConsumer(consumerId: request.consumerId, success: { [weak self] () in
            self?.success(callback: success)
        }, failure: { [weak self] (error) in
            self?.failure(error: error, callback: failure)
        })
        
    }
    
    private func success(callback: @escaping (DeleteConsumerResponse) -> Void) {
        self.response = DeleteConsumerResponse()
        invokeSuccess(callback: callback, response: self.response!)
    }
    
    private func failure(error: DeleteConsumerError, callback: @escaping (DeleteConsumerError) -> Void) {
        self.error = error
        invokeFailure(callback: callback, failure: error)
    }
        
}


