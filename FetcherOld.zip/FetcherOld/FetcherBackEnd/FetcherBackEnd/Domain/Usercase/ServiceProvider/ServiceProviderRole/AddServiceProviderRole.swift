//
//  AddServiceProviderRole.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 02/03/23.
//

import Foundation
import VTComponents

public final class AddServiceProviderRoleRequest: ZRequest {
    var serviceProviderRole: ServiceProviderRole
    public init(serviceProviderRole: ServiceProviderRole) {
        self.serviceProviderRole = serviceProviderRole
        super.init(zuid: " ")
    }
}

public final class AddServiceProviderRoleResponse: ZResponse {
    public override init() {
        
    }
}

public final class AddServiceProviderRoleError: ZError {
    
}

public final class AddServiceProviderRole: ZUsecase<AddServiceProviderRoleRequest, AddServiceProviderRoleResponse, AddServiceProviderRoleError> {
    var dataManager: AddServiceProviderRoleDataContract
    public var response: AddServiceProviderRoleResponse?
    
    public init(dataManager: AddServiceProviderRoleDataContract) {
        self.dataManager = dataManager
    }
    
    public override func run(request: AddServiceProviderRoleRequest, success: @escaping (AddServiceProviderRoleResponse) -> Void, failure: @escaping (AddServiceProviderRoleError) -> Void) {
        dataManager.addServiceProviderRole(serviceProviderRole: request.serviceProviderRole, success: { [weak self] () in
            self?.success(callback: success)

        }, failure: { [weak self] (error) in
            self?.failure(error: error, callback: failure)

        })
    }
    
    private func success(callback: @escaping (AddServiceProviderRoleResponse) -> Void) {
        self.response = AddServiceProviderRoleResponse()
        invokeSuccess(callback: callback, response: self.response!)
    }
    
    private func failure(error: AddServiceProviderRoleError, callback: @escaping (AddServiceProviderRoleError) -> Void) {
        invokeFailure(callback: callback, failure: error)
    }
}


