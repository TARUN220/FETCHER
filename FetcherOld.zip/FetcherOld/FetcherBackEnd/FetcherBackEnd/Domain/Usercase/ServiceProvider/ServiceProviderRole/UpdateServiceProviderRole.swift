//
//  UpdateServiceProviderRole.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 10/03/23.
//

import Foundation
import VTComponents

public final class UpdateServiceProviderRoleRequest: ZRequest {
    
    var newValues: [String: Any]
    var serviceProviderRoleId: Int
    public init(newValues: [String: Any], serviceProviderRoleId: Int) {
        self.newValues = newValues
        self.serviceProviderRoleId = serviceProviderRoleId
        super.init(zuid: " ")
    }
}
public final class UpdateServiceProviderRoleResponse: ZResponse {

    public override init() {
        
    }
}

public final class UpdateServiceProviderRoleError: ZError {
    
}

public final class UpdateServiceProviderRole: ZUsecase<UpdateServiceProviderRoleRequest, UpdateServiceProviderRoleResponse, UpdateServiceProviderRoleError> {
    var dataManager: UpdateServiceProviderRoleDataContract
    public var response: UpdateServiceProviderRoleResponse?
    public var error: UpdateServiceProviderRoleError?
    
    public init(dataManager: UpdateServiceProviderRoleDataContract) {
        self.dataManager = dataManager
    }
    
    public override func run(request: UpdateServiceProviderRoleRequest, success: @escaping (UpdateServiceProviderRoleResponse) -> Void, failure: @escaping (UpdateServiceProviderRoleError) -> Void) {
        dataManager.updateServiceProviderRole(newValues: request.newValues, serviceProviderRoleId: request.serviceProviderRoleId, success: { [weak self] () in
            self?.success(callback: success)
        }, failure: { [weak self] (error) in
            self?.failure(error: error, callback: failure)
        })
        
    }
    
    private func success(callback: @escaping (UpdateServiceProviderRoleResponse) -> Void) {
        self.response = UpdateServiceProviderRoleResponse()
        invokeSuccess(callback: callback, response: self.response!)
    }
    
    private func failure(error: UpdateServiceProviderRoleError, callback: @escaping (UpdateServiceProviderRoleError) -> Void) {
        self.error = error
        invokeFailure(callback: callback, failure: error)
    }
        
}


