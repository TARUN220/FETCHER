//
//  SearchServiceProviderRole.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 02/03/23.
//

import Foundation
import VTComponents

public final class SearchServiceProviderRoleRequest: ZRequest {
    public var columnName: String
    public var columnType: Any
    public init(columnName: String, columnType: Any) {
        self.columnName = columnName
        self.columnType = columnType
        super.init(zuid: " ")
    }
}

public final class SearchServiceProviderRoleResponse: ZResponse {
    public var serviceProviderRole: [ServiceProviderRole]
    public init(serviceProviderRole: [ServiceProviderRole]) {
        self.serviceProviderRole = serviceProviderRole
    }
}

public final class SearchServiceProviderRoleError: ZError {
    
}

public final class SearchServiceProviderRole: ZUsecase<SearchServiceProviderRoleRequest, SearchServiceProviderRoleResponse, SearchServiceProviderRoleError> {
    var dataManager: SearchServiceProviderRoleDataContract
    public var searchServiceProviderRoleResponse: SearchServiceProviderRoleResponse?
    public var searchServiceProviderRoleError: SearchServiceProviderRoleError?
    public init(dataManager: SearchServiceProviderRoleDataContract) {
        self.dataManager = dataManager
    }
    
    public override func run(request: SearchServiceProviderRoleRequest, success: @escaping (SearchServiceProviderRoleResponse) -> Void, failure: @escaping (SearchServiceProviderRoleError) -> Void) {
//        print("Search ServiceProviderRole usecase")
        dataManager.searchServiceProviderRole(success: { [weak self] (serviceProviderRole) in
            self?.success(serviceProviderRole: serviceProviderRole, callback: success)
        }, failure: { [weak self] (error) in
            self?.failure(error: error, callback: failure)
        })
    }
    
    private func success(serviceProviderRole: [ServiceProviderRole], callback: @escaping (SearchServiceProviderRoleResponse) -> Void) {
        let response = SearchServiceProviderRoleResponse(serviceProviderRole: serviceProviderRole)
        self.searchServiceProviderRoleResponse = response
        invokeSuccess(callback: callback, response: response)
    }
    
    private func failure(error: SearchServiceProviderRoleError, callback: @escaping (SearchServiceProviderRoleError) -> Void) {
        self.searchServiceProviderRoleError = error
        invokeFailure(callback: callback, failure: error)
    }
}
