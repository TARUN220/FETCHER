//
//  GetServiceProviderRole.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 02/03/23.
//

import Foundation
import VTComponents

public final class GetServiceProviderRoleListRequest: ZRequest {
    
    public init() {
        super.init(zuid: " ")
    }
}

public final class GetServiceProviderRoleListResponse: ZResponse {
    public var serviceProviderRole: [ServiceProviderRole]
    public init(serviceProviderRole: [ServiceProviderRole]) {
        self.serviceProviderRole = serviceProviderRole
    }
}

public final class GetServiceProviderRoleListError: ZError {
    
}

public final class GetServiceProviderRoleList: ZUsecase<GetServiceProviderRoleListRequest, GetServiceProviderRoleListResponse, GetServiceProviderRoleListError> {
    var dataManager: GetServiceProviderRoleListDataContract
    public var response: GetServiceProviderRoleListResponse?
    public var error: GetServiceProviderRoleListError?
    
    public init(dataManager: GetServiceProviderRoleListDataContract) {
        self.dataManager = dataManager
    }
    
    public override func run(request: GetServiceProviderRoleListRequest, success: @escaping (GetServiceProviderRoleListResponse) -> Void, failure: @escaping (GetServiceProviderRoleListError) -> Void) {
        dataManager.getServiceProviderRoleList(success: { [weak self] (serviceProviderRole) in
            self?.success(serviceProviderRole: serviceProviderRole, callback: success)
        }, failure: { [weak self] (error) in
            self?.failure(error: error, callback: failure)
        })
    }
    
    private func success(serviceProviderRole: [ServiceProviderRole], callback: @escaping (GetServiceProviderRoleListResponse) -> Void) {
        self.response = GetServiceProviderRoleListResponse(serviceProviderRole: serviceProviderRole)
        invokeSuccess(callback: callback, response: self.response!)
    }

    private func failure(error: GetServiceProviderRoleListError, callback: @escaping (GetServiceProviderRoleListError) -> Void) {
        self.error = error
        invokeFailure(callback: callback, failure: error)
    }
}


