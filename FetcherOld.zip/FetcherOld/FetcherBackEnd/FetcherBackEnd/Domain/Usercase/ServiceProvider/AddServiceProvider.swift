//
//  AddServiceProvider.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 02/03/23.
//

import Foundation
import VTComponents

public final class AddServiceProviderRequest: ZRequest {
    var serviceProvider: ServiceProvider
    public init(serviceProvider: ServiceProvider) {
        self.serviceProvider = serviceProvider
        super.init(zuid: " ")
    }
}

public final class AddServiceProviderResponse: ZResponse {
    public override init() {
        
    }
}

public final class AddServiceProviderError: ZError {
    
}

public final class AddServiceProvider: ZUsecase<AddServiceProviderRequest, AddServiceProviderResponse, AddServiceProviderError> {
    var dataManager: AddServiceProviderDataContract
    public var response: AddServiceProviderResponse?
    
    public init(dataManager: AddServiceProviderDataContract) {
        self.dataManager = dataManager
    }
    
    public override func run(request: AddServiceProviderRequest, success: @escaping (AddServiceProviderResponse) -> Void, failure: @escaping (AddServiceProviderError) -> Void) {
        dataManager.addServiceProvider(serviceProvider: request.serviceProvider, success: { [weak self] () in
            self?.success(callback: success)
        }, failure: { [weak self] (error) in
            self?.failure(error: error, callback: failure)
        })
    }
    
    private func success(callback: @escaping (AddServiceProviderResponse) -> Void) {
        self.response = AddServiceProviderResponse()
        invokeSuccess(callback: callback, response: self.response!)
    }
    
    private func failure(error: AddServiceProviderError, callback: @escaping (AddServiceProviderError) -> Void) {
        invokeFailure(callback: callback, failure: error)
    }
}
