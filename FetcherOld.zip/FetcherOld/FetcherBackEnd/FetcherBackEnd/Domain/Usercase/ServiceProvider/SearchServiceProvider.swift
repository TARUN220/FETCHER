//
//  SearchServiceProvider.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 03/03/23.
//

import Foundation
import VTComponents


public final class SearchServiceProviderRequest: ZRequest {
    public var columnName: String
    public var columnType: Any
    public init(columnName: String, columnType: Any) {
        self.columnName = columnName
        self.columnType = columnType
        super.init(zuid: " ")
    }
}

public final class SearchServiceProviderResponse: ZResponse {
    public var serviceProvider: [ServiceProvider]
    public init(serviceProvider: [ServiceProvider]) {
        self.serviceProvider = serviceProvider
    }
}

public final class SearchServiceProviderError: ZError {
    
}

public final class SearchServiceProvider: ZUsecase<SearchServiceProviderRequest, SearchServiceProviderResponse, SearchServiceProviderError> {
    var dataManager: SearchServiceProviderDataContract
    public var searchServiceProviderResponse: SearchServiceProviderResponse?
    public var searchServiceProviderError: SearchServiceProviderError?
    public init(dataManager: SearchServiceProviderDataContract) {
        self.dataManager = dataManager
    }
    
    public override func run(request: SearchServiceProviderRequest, success: @escaping (SearchServiceProviderResponse) -> Void, failure: @escaping (SearchServiceProviderError) -> Void) {
//        print("Search ServiceProvider usecase")
        dataManager.searchServiceProvider(success: { [weak self] (serviceProvider) in
            self?.success(serviceProvider: serviceProvider, callback: success)
        }, failure: { [weak self] (error) in
            self?.failure(error: error, callback: failure)
        })
    }
    
    private func success(serviceProvider: [ServiceProvider], callback: @escaping (SearchServiceProviderResponse) -> Void) {
        let response = SearchServiceProviderResponse(serviceProvider: serviceProvider)
        self.searchServiceProviderResponse = response
        invokeSuccess(callback: callback, response: response)
    }
    
    private func failure(error: SearchServiceProviderError, callback: @escaping (SearchServiceProviderError) -> Void) {
        self.searchServiceProviderError = error
        invokeFailure(callback: callback, failure: error)
    }
}
