//
//  GetServiceProvider.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 08/03/23.
//

import Foundation
import VTComponents

public final class GetServiceProviderListRequest: ZRequest {
    
    public init() {
        super.init(zuid: " ")
    }
}

public final class GetServiceProviderListResponse: ZResponse {
    public var serviceProvider: [ServiceProvider]
    public init(serviceProvider: [ServiceProvider]) {
        self.serviceProvider = serviceProvider
    }
}

public final class GetServiceProviderListError: ZError {
    
}

public final class GetServiceProviderList: ZUsecase<GetServiceProviderListRequest, GetServiceProviderListResponse, GetServiceProviderListError> {
    var dataManager: GetServiceProviderListDataContract
    public var response: GetServiceProviderListResponse?
    public var error: GetServiceProviderListError?
    
    public init(dataManager: GetServiceProviderListDataContract) {
        self.dataManager = dataManager
    }
    
    public override func run(request: GetServiceProviderListRequest, success: @escaping (GetServiceProviderListResponse) -> Void, failure: @escaping (GetServiceProviderListError) -> Void) {
        dataManager.getServiceProviderList(success: { [weak self] (serviceProvider) in
            self?.success(serviceProvider: serviceProvider, callback: success)
        }, failure: { [weak self] (error) in
            self?.failure(error: error, callback: failure)
        })
    }
    
    private func success(serviceProvider: [ServiceProvider], callback: @escaping (GetServiceProviderListResponse) -> Void) {
        self.response = GetServiceProviderListResponse(serviceProvider: serviceProvider)
        invokeSuccess(callback: callback, response: self.response!)
    }

    private func failure(error: GetServiceProviderListError, callback: @escaping (GetServiceProviderListError) -> Void) {
        self.error = error
        invokeFailure(callback: callback, failure: error)
    }
}


