//
//  UpdateServiceProvider.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 14/03/23.
//

import Foundation
import VTComponents

public final class UpdateServiceProviderRequest: ZRequest {
    
    var newValues: [String: Any]
    var serviceProviderId: Int
    public init(newValues: [String: Any], serviceProviderId: Int) {
        self.newValues = newValues
        self.serviceProviderId = serviceProviderId
        super.init(zuid: " ")
    }
}
public final class UpdateServiceProviderResponse: ZResponse {

    public override init() {
        
    }
}

public final class UpdateServiceProviderError: ZError {
    
}

public final class UpdateServiceProvider: ZUsecase<UpdateServiceProviderRequest, UpdateServiceProviderResponse, UpdateServiceProviderError> {
    var dataManager: UpdateServiceProviderDataContract
    
    public init(dataManager: UpdateServiceProviderDataContract) {
        self.dataManager = dataManager
    }
    
    public override func run(request: UpdateServiceProviderRequest, success: @escaping (UpdateServiceProviderResponse) -> Void, failure: @escaping (UpdateServiceProviderError) -> Void) {        dataManager.updateServiceProvider(newValues: request.newValues, serviceProviderId: request.serviceProviderId, success: { [weak self] () in
            self?.success(callback: success)
        }, failure: { [weak self] (error) in
            self?.failure(error: error, callback: failure)
        })
        
    }
    
    private func success(callback: @escaping (UpdateServiceProviderResponse) -> Void) {
        let response = UpdateServiceProviderResponse()
        invokeSuccess(callback: callback, response: response)
    }
    
    private func failure(error: UpdateServiceProviderError, callback: @escaping (UpdateServiceProviderError) -> Void) {
        invokeFailure(callback: callback, failure: error)
    }
        
}


