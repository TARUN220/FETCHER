//
//  DeleteServiceProvider.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 13/03/23.
//

import Foundation
import VTComponents

public final class DeleteServiceProviderRequest: ZRequest {
    
    var serviceProviderId: Int
    public init(serviceProviderId: Int) {
        self.serviceProviderId = serviceProviderId
        super.init(zuid: " ")
    }
}
public final class DeleteServiceProviderResponse: ZResponse {

    public override init() {
        
    }
}

public final class DeleteServiceProviderError: ZError {
    
}

public final class DeleteServiceProvider: ZUsecase<DeleteServiceProviderRequest, DeleteServiceProviderResponse, DeleteServiceProviderError> {
    var dataManager: DeleteServiceProviderDataContract
    public var response: DeleteServiceProviderResponse?
    public var error: DeleteServiceProviderError?
    
    public init(dataManager: DeleteServiceProviderDataContract) {
        self.dataManager = dataManager
    }
    
    public override func run(request: DeleteServiceProviderRequest, success: @escaping (DeleteServiceProviderResponse) -> Void, failure: @escaping (DeleteServiceProviderError) -> Void) {
        dataManager.deleteServiceProvider(serviceProviderId: request.serviceProviderId, success: { [weak self] () in
            self?.success(callback: success)
        }, failure: { [weak self] (error) in
            self?.failure(error: error, callback: failure)
        })
        
    }
    
    private func success(callback: @escaping (DeleteServiceProviderResponse) -> Void) {
        self.response = DeleteServiceProviderResponse()
        invokeSuccess(callback: callback, response: self.response!)
    }
    
    private func failure(error: DeleteServiceProviderError, callback: @escaping (DeleteServiceProviderError) -> Void) {
        self.error = error
        invokeFailure(callback: callback, failure: error)
    }
        
}


