//
//  NewService.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 08/03/23.
//

import Foundation
import VTComponents

public final class NewServiceRequest: ZRequest {
    var service: Service
    public init(service: Service) {
        self.service = service
        super.init(zuid: " ")
    }
}

public final class NewServiceResponse: ZResponse {
    public override init() {
        
    }
}

public final class NewServiceError: ZError {
    
}

public final class NewService: ZUsecase<NewServiceRequest, NewServiceResponse, NewServiceError> {
    var dataManager: NewServiceDataContract
    public var response: NewServiceResponse?
    public var error: NewServiceError?
    
    public init(dataManager: NewServiceDataContract) {
        self.dataManager = dataManager
    }
    
    public override func run(request: NewServiceRequest, success: @escaping (NewServiceResponse) -> Void, failure: @escaping (NewServiceError) -> Void) {
        dataManager.newService(service: request.service, success: { [weak self] () in
            self?.success(callback: success)
            
        }, failure: { [weak self] (error) in
            self?.failure(error: error, callback: failure)
            
        })
    }
    
    private func success(callback: @escaping (NewServiceResponse) -> Void) {
        self.response = NewServiceResponse()
        invokeSuccess(callback: callback, response: self.response!)
    }
    
    private func failure(error: NewServiceError, callback: @escaping (NewServiceError) -> Void) {
        self.error = error
        invokeFailure(callback: callback, failure: error)
    }
}
