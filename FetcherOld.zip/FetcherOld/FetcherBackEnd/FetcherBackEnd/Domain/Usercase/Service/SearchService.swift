//
//  SearchService.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 09/03/23.
//

import Foundation
import VTComponents

public final class SearchServiceRequest: ZRequest {
    public var columnName: String
    public var columnType: Any
    public init(columnName: String, columnType: Any) {
        self.columnName = columnName
        self.columnType = columnType
        super.init(zuid: " ")
    }
}

public final class SearchServiceResponse: ZResponse {
    public var service: [Service]
    public init(service: [Service]) {
        self.service = service
    }
}

public final class SearchServiceError: ZError {
    
}

public final class SearchService: ZUsecase<SearchServiceRequest, SearchServiceResponse, SearchServiceError> {
    var dataManager: SearchServiceDataContract
    public var searchServiceResponse: SearchServiceResponse?
    public var searchServiceError: SearchServiceError?
    public init(dataManager: SearchServiceDataContract) {
        self.dataManager = dataManager
    }
    
    public override func run(request: SearchServiceRequest, success: @escaping (SearchServiceResponse) -> Void, failure: @escaping (SearchServiceError) -> Void) {
//        print("Search Service usecase")
        dataManager.searchService(success: { [weak self] (service) in
            self?.success(service: service, callback: success)
        }, failure: { [weak self] (error) in
            self?.failure(error: error, callback: failure)
        })
    }
    
    private func success(service: [Service], callback: @escaping (SearchServiceResponse) -> Void) {
        let response = SearchServiceResponse(service: service)
        self.searchServiceResponse = response
        invokeSuccess(callback: callback, response: response)
    }
    
    private func failure(error: SearchServiceError, callback: @escaping (SearchServiceError) -> Void) {
        self.searchServiceError = error
        invokeFailure(callback: callback, failure: error)
    }
}
