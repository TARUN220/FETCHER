//
//  GetServiceRequestList.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 08/03/23.
//

import Foundation
import VTComponents

public final class GetServiceRequestListRequest: ZRequest {
    public var columnName: String
    public var columnType: Any
    public init(columnName: String, columnType: Any) {
        self.columnName = columnName
        self.columnType = columnType
        super.init(zuid: " ")
    }
}

public final class GetServiceRequestListResponse: ZResponse {
    public var service: [Service]
    public init(service: [Service]) {
        self.service = service
    }
}

public final class GetServiceRequestListError: ZError {
    
}

public final class GetServiceRequestList: ZUsecase<GetServiceRequestListRequest, GetServiceRequestListResponse, GetServiceRequestListError> {
    var dataManager: GetServiceRequestListDataContract
    public var response: GetServiceRequestListResponse?
    public var error: GetServiceRequestListError?
    
    public init(dataManager: GetServiceRequestListDataContract) {
        self.dataManager = dataManager
    }
    
    public override func run(request: GetServiceRequestListRequest, success: @escaping (GetServiceRequestListResponse) -> Void, failure: @escaping (GetServiceRequestListError) -> Void) {
        dataManager.getServiceRequestList(success: { [weak self] (serviceRequest) in
            self?.success(service: serviceRequest, callback: success)
        }, failure: { [weak self] (error) in
            self?.failure(error: error, callback: failure)
        })
    }
    
    private func success(service: [Service], callback: @escaping (GetServiceRequestListResponse) -> Void) {
        self.response = GetServiceRequestListResponse(service: service)
        invokeSuccess(callback: callback, response: self.response!)
    }

    private func failure(error: GetServiceRequestListError, callback: @escaping (GetServiceRequestListError) -> Void) {
        self.error = error
        invokeFailure(callback: callback, failure: error)
    }
}


