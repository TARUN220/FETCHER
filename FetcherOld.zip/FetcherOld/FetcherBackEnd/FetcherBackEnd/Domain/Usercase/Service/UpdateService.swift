//
//  UpdateService.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 09/03/23.
//

import Foundation
import VTComponents

public final class UpdateServiceRequest: ZRequest {
    
    var newValues: [String: Any]
    var serviceId: Int
    public init(newValues: [String: Any], serviceId: Int) {
        self.newValues = newValues
        self.serviceId = serviceId
        super.init(zuid: " ")
    }
}
public final class UpdateServiceResponse: ZResponse {

    public override init() {
        
    }
}

public final class UpdateServiceError: ZError {
    
}

public final class UpdateService: ZUsecase<UpdateServiceRequest, UpdateServiceResponse, UpdateServiceError> {
    var dataManager: UpdateServiceDataContract
    public var response: UpdateServiceResponse?
    public var error: UpdateServiceError?
    
    public init(dataManager: UpdateServiceDataContract) {
        self.dataManager = dataManager
    }
    
    public override func run(request: UpdateServiceRequest, success: @escaping (UpdateServiceResponse) -> Void, failure: @escaping (UpdateServiceError) -> Void) {
        dataManager.updateService(newValues: request.newValues, serviceId: request.serviceId, success: { [weak self] () in
            self?.success(callback: success)
        }, failure: { [weak self] (error) in
            self?.failure(error: error, callback: failure)
        })
        
    }
    
    private func success(callback: @escaping (UpdateServiceResponse) -> Void) {
        self.response = UpdateServiceResponse()
        invokeSuccess(callback: callback, response: self.response!)
    }
    
    private func failure(error: UpdateServiceError, callback: @escaping (UpdateServiceError) -> Void) {
        self.error = error
        invokeFailure(callback: callback, failure: error)
    }
        
}


