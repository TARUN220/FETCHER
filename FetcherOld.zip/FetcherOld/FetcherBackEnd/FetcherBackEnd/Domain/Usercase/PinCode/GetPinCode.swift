//
//  GetPin.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 07/03/23.
//

import Foundation
import VTComponents

public final class GetPinCodeListRequest: ZRequest {
    
    public init() {
        super.init(zuid: " ")
    }
}

public final class GetPinCodeListResponse: ZResponse {
    public var pinCode: [PinCode]
    public init(pinCode: [PinCode]) {
        self.pinCode = pinCode
    }
}

public final class GetPinCodeListError: ZError {
    
}

public final class GetPinCodeList: ZUsecase<GetPinCodeListRequest, GetPinCodeListResponse, GetPinCodeListError> {
    var dataManager: GetPinCodeListDataContract
    public var response: GetPinCodeListResponse?
    public var error: GetPinCodeListError?
    
    public init(dataManager: GetPinCodeListDataContract) {
        self.dataManager = dataManager
    }
    
    public override func run(request: GetPinCodeListRequest, success: @escaping (GetPinCodeListResponse) -> Void, failure: @escaping (GetPinCodeListError) -> Void) {
        dataManager.getPinCodeList(success: { [weak self] (pinCode) in
            self?.success(pinCode: pinCode, callback: success)
        }, failure: { [weak self] (error) in
            self?.failure(error: error, callback: failure)
        })
    }
    
    private func success(pinCode: [PinCode], callback: @escaping (GetPinCodeListResponse) -> Void) {
        self.response = GetPinCodeListResponse(pinCode: pinCode)
        invokeSuccess(callback: callback, response: self.response!)
    }

    private func failure(error: GetPinCodeListError, callback: @escaping (GetPinCodeListError) -> Void) {
        self.error = error
        invokeFailure(callback: callback, failure: error)
    }
}


