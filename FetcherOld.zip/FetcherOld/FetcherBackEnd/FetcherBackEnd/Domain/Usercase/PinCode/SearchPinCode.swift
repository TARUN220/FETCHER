//
//  SearchPinCode.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 07/03/23.
//

import Foundation
import VTComponents

public final class SearchPinCodeRequest: ZRequest {
    public var columnName: String
    public var columnType: Any
    public init(columnName: String, columnType: Any) {
        self.columnName = columnName
        self.columnType = columnType
        super.init(zuid: " ")
    }
}

public final class SearchPinCodeResponse: ZResponse {
    public var pinCode: [PinCode]
    public init(pinCode: [PinCode]) {
        self.pinCode = pinCode
    }
}

public final class SearchPinCodeError: ZError {
    
}

public final class SearchPinCode: ZUsecase<SearchPinCodeRequest, SearchPinCodeResponse, SearchPinCodeError> {
    var dataManager: SearchPinCodeDataContract
    public var searchPinCodeResponse: SearchPinCodeResponse?
    public var searchPinCodeError: SearchPinCodeError?
    public init(dataManager: SearchPinCodeDataContract) {
        self.dataManager = dataManager
    }
    
    public override func run(request: SearchPinCodeRequest, success: @escaping (SearchPinCodeResponse) -> Void, failure: @escaping (SearchPinCodeError) -> Void) {
//        print("Search PinCode usecase")
        dataManager.searchPinCode(success: { [weak self] (pinCode) in
            self?.success(pinCode: pinCode, callback: success)
        }, failure: { [weak self] (error) in
            self?.failure(error: error, callback: failure)
        })
    }
    
    private func success(pinCode: [PinCode], callback: @escaping (SearchPinCodeResponse) -> Void) {
        let response = SearchPinCodeResponse(pinCode: pinCode)
        self.searchPinCodeResponse = response
        invokeSuccess(callback: callback, response: response)
    }
    
    private func failure(error: SearchPinCodeError, callback: @escaping (SearchPinCodeError) -> Void) {
        self.searchPinCodeError = error
        invokeFailure(callback: callback, failure: error)
    }
}
