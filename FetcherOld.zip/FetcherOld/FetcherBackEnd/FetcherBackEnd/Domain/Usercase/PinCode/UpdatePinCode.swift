//
//  UpdatePinCode.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 13/03/23.
//

import Foundation
import VTComponents

public final class UpdatePinCodeRequest: ZRequest {
    
    var newValues: [String: Any]
    var pinCodeId: Int
    public init(newValues: [String: Any], pinCodeId: Int) {
        self.newValues = newValues
        self.pinCodeId = pinCodeId
        super.init(zuid: " ")
    }
}
public final class UpdatePinCodeResponse: ZResponse {

    public override init() {
        
    }
}

public final class UpdatePinCodeError: ZError {
    
}

public final class UpdatePinCode: ZUsecase<UpdatePinCodeRequest, UpdatePinCodeResponse, UpdatePinCodeError> {
    var dataManager: UpdatePinCodeDataContract
    public var response: UpdatePinCodeResponse?
    public var error: UpdatePinCodeError?
    
    public init(dataManager: UpdatePinCodeDataContract) {
        self.dataManager = dataManager
    }
    
    public override func run(request: UpdatePinCodeRequest, success: @escaping (UpdatePinCodeResponse) -> Void, failure: @escaping (UpdatePinCodeError) -> Void) {
        dataManager.updatePinCode(newValues: request.newValues, pinCodeId: request.pinCodeId, success: { [weak self] () in
            self?.success(callback: success)
        }, failure: { [weak self] (error) in
            self?.failure(error: error, callback: failure)
        })
        
    }
    
    private func success(callback: @escaping (UpdatePinCodeResponse) -> Void) {
        self.response = UpdatePinCodeResponse()
        invokeSuccess(callback: callback, response: self.response!)
    }
    
    private func failure(error: UpdatePinCodeError, callback: @escaping (UpdatePinCodeError) -> Void) {
        self.error = error
        invokeFailure(callback: callback, failure: error)
    }
        
}


