//
//  AddPin.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 07/03/23.
//

import Foundation
import VTComponents

public final class AddPinCodeRequest: ZRequest {
    var pinCode: PinCode
    public init(pinCode: PinCode) {
        self.pinCode = pinCode
        super.init(zuid: " ")
    }
}

public final class AddPinCodeResponse: ZResponse {
    public override init() {
        
    }
}

public final class AddPinCodeError: ZError {
    
}

public final class AddPinCode: ZUsecase<AddPinCodeRequest, AddPinCodeResponse, AddPinCodeError> {
    var dataManager: AddPinCodeDataContract
    public var response: AddPinCodeResponse?

    public init(dataManager: AddPinCodeDataContract) {
        self.dataManager = dataManager
    }

    public override func run(request: AddPinCodeRequest, success: @escaping (AddPinCodeResponse) -> Void, failure: @escaping (AddPinCodeError) -> Void) {
        dataManager.addPinCode(pinCode: request.pinCode, success: { [weak self] () in
            self?.success(callback: success)

        }, failure: { [weak self] (error) in
            self?.failure(error: error, callback: failure)

        })
    }
    
    private func success(callback: @escaping (AddPinCodeResponse) -> Void) {
        self.response = AddPinCodeResponse()
        invokeSuccess(callback: callback, response: self.response!)
    }
    
    private func failure(error: AddPinCodeError, callback: @escaping (AddPinCodeError) -> Void) {
        invokeFailure(callback: callback, failure: error)
    }
}


