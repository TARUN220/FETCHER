//
//  SearchAdmin.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 01/03/23.
//

import Foundation
import VTComponents

public final class SearchAdminRequest: ZRequest {
    public var columnName: String
    public var columnValue: Any
    public init(columnName: String, columnValue: Any) {
        self.columnName = columnName
        self.columnValue = columnValue
        super.init(zuid: " ")
    }
}

public final class SearchAdminResponse: ZResponse {
    public var admin: [Admin]
    public init(admin: [Admin]) {
        self.admin = admin
    }
}

public final class SearchAdminError: ZError {
    
}

public class SearchAdmin: ZUsecase<SearchAdminRequest, SearchAdminResponse, SearchAdminError> {
    var dataManager: SearchAdminDataContract
    public var searchAdminResponse: SearchAdminResponse?
    public var searchAdminError: SearchAdminError?
    public init(dataManager: SearchAdminDataContract) {
        self.dataManager = dataManager
    }
    
    public override func run(request: SearchAdminRequest, success: @escaping (SearchAdminResponse) -> Void, failure: @escaping (SearchAdminError) -> Void) {
        print("Search Admin usecase")
        dataManager.searchAdmin(success: { [weak self] (admin) in
            self?.success(admin: admin, callback: success)
        }, failure: { [weak self] (error) in
            self?.failure(error: error, callback: failure)
        })
    }
    
    private func success(admin: [Admin], callback: @escaping (SearchAdminResponse) -> Void) {
        let response = SearchAdminResponse(admin: admin)
        self.searchAdminResponse = response
        invokeSuccess(callback: callback, response: response)
    }
    
    private func failure(error: SearchAdminError, callback: @escaping (SearchAdminError) -> Void) {
        self.searchAdminError = error
        invokeFailure(callback: callback, failure: error)
    }
}
