//
//  UpdateAdmin.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 14/03/23.
//

import Foundation
import VTComponents

public final class UpdateAdminRequest: ZRequest {
    
    var newValues: [String: Any]
    var adminId: Int
    public init(newValues: [String: Any], adminId: Int) {
        self.newValues = newValues
        self.adminId = adminId
        super.init(zuid: " ")
    }
}
public final class UpdateAdminResponse: ZResponse {

    public override init() {
        
    }
}

public final class UpdateAdminError: ZError {
    
}

public final class UpdateAdmin: ZUsecase<UpdateAdminRequest, UpdateAdminResponse, UpdateAdminError> {
    var dataManager: UpdateAdminDataContract
    
    public init(dataManager: UpdateAdminDataContract) {
        self.dataManager = dataManager
    }
    
    public override func run(request: UpdateAdminRequest, success: @escaping (UpdateAdminResponse) -> Void, failure: @escaping (UpdateAdminError) -> Void) {        dataManager.updateAdmin(newValues: request.newValues, adminId: request.adminId, success: { [weak self] () in
            self?.success(callback: success)
        }, failure: { [weak self] (error) in
            self?.failure(error: error, callback: failure)
        })
        
    }
    
    private func success(callback: @escaping (UpdateAdminResponse) -> Void) {
        let response = UpdateAdminResponse()
        invokeSuccess(callback: callback, response: response)
    }
    
    private func failure(error: UpdateAdminError, callback: @escaping (UpdateAdminError) -> Void) {
        invokeFailure(callback: callback, failure: error)
    }
        
}


