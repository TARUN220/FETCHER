//
//  SearchServiceProviderContract.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 02/03/23.
//

import Foundation

public protocol SearchServiceProviderDataContract {
    func searchServiceProvider(success: @escaping ([ServiceProvider]) -> Void, failure: @escaping (SearchServiceProviderError) -> Void)
}
