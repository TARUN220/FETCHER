//
//  UpdateServiceProviderContract.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 14/03/23.
//

import Foundation
public protocol UpdateServiceProviderDataContract {
    func updateServiceProvider(newValues: [String: Any], serviceProviderId: Int, success: @escaping () -> Void, failure: @escaping (UpdateServiceProviderError) -> Void)
}
