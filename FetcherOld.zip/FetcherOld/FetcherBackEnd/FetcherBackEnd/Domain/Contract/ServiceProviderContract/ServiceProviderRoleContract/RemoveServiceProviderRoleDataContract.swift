//
//  RemoveServiceProviderRoleDataContract.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 02/03/23.
//

import Foundation
