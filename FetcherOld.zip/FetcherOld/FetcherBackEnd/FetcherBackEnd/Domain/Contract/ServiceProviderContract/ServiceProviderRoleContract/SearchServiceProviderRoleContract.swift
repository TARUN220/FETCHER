//
//  SearchServiceProviderRoleContract.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 02/03/23.
//

import Foundation

public protocol SearchServiceProviderRoleDataContract {
    func searchServiceProviderRole(success: @escaping ([ServiceProviderRole]) -> Void, failure: @escaping (SearchServiceProviderRoleError) -> Void)
}
