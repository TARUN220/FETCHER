//
//  UpdateServiceProviderRoleContract.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 10/03/23.
//

import Foundation
public protocol UpdateServiceProviderRoleDataContract {
    func updateServiceProviderRole(newValues: [String: Any], serviceProviderRoleId: Int, success: @escaping () -> Void, failure: @escaping (UpdateServiceProviderRoleError) -> Void)
}
