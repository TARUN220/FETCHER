//
//  GetServiceProviderListContract.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 08/03/23.
//

import Foundation

public protocol GetServiceProviderListDataContract {
    func getServiceProviderList(success: @escaping ([ServiceProvider]) -> Void, failure: @escaping (GetServiceProviderListError) -> Void)
}
