//
//  DeleteServiceProviderCOntract.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 13/03/23.
//

import Foundation

public protocol DeleteServiceProviderDataContract {
    func deleteServiceProvider(serviceProviderId: Int, success: @escaping () -> Void, failure: @escaping (DeleteServiceProviderError) -> Void)
}
