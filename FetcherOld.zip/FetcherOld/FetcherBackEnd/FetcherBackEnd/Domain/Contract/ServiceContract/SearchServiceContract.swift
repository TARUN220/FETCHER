//
//  SearchServiceRequestListContract.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 09/03/23.
//

import Foundation

public protocol SearchServiceDataContract {
    func searchService(success: @escaping ([Service]) -> Void, failure: @escaping (SearchServiceError) -> Void)
}
