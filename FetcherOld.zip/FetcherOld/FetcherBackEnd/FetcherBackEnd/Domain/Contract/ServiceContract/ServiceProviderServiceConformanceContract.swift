//
//  ConsumerServiceConformanceContract.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 09/03/23.
//

import Foundation

//public protocol ServiceProviderServiceConformanceDataContract {
//    func serviceProviderServiceConformance(consumer: Consumer, success: @escaping () -> Void, failure: @escaping (ServiceProviderServiceConformanceError) -> Void)
//}
