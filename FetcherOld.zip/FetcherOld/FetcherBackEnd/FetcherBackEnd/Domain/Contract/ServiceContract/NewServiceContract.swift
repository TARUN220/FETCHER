//
//  NewServiceContract.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 08/03/23.
//

import Foundation

public protocol NewServiceDataContract {
    func newService(service: Service, success: @escaping () -> Void, failure: @escaping (NewServiceError) -> Void)
}
