//
//  GetServiceRequestListContract.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 08/03/23.
//

import Foundation

public protocol GetServiceRequestListDataContract {
    func getServiceRequestList(success: @escaping ([Service]) -> Void, failure: @escaping (GetServiceRequestListError) -> Void)
}
