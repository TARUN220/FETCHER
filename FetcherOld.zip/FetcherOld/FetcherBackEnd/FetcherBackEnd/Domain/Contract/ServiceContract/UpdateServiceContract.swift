//
//  UpdateServiceContract.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 09/03/23.
//

import Foundation

public protocol UpdateServiceDataContract {
    func updateService(newValues: [String: Any], serviceId: Int, success: @escaping () -> Void, failure: @escaping (UpdateServiceError) -> Void)
}
