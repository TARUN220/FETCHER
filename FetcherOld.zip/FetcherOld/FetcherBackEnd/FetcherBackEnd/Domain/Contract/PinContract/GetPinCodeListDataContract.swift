//
//  GetPinListDataContract.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 07/03/23.
//

import Foundation

public protocol GetPinCodeListDataContract {
    func getPinCodeList(success: @escaping ([PinCode]) -> Void, failure: @escaping (GetPinCodeListError) -> Void)
}
