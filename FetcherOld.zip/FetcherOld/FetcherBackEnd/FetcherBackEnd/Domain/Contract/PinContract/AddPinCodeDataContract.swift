//
//  AddPinDataContract.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 07/03/23.
//

import Foundation

public protocol AddPinCodeDataContract {
    func addPinCode(pinCode: PinCode, success: @escaping () -> Void, failure: @escaping (AddPinCodeError) -> Void)
}
