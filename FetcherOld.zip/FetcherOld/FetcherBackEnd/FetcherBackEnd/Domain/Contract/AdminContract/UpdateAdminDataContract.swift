//
//  UpdateAdminDataContract.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 14/03/23.
//


import Foundation
public protocol UpdateAdminDataContract {
    func updateAdmin(newValues: [String: Any], adminId: Int, success: @escaping () -> Void, failure: @escaping (UpdateAdminError) -> Void)
}
