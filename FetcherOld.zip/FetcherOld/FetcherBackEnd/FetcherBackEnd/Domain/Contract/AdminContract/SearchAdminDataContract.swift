//
//  SearchAdminDataContract.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 01/03/23.
//

import Foundation

public protocol SearchAdminDataContract {
    func searchAdmin(success: @escaping ([Admin]) -> Void, failure: @escaping (SearchAdminError) -> Void)
}
