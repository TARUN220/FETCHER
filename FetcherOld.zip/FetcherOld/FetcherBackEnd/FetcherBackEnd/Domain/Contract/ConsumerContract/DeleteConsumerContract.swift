//
//  DeleteConsumerContract.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 13/03/23.
//

import Foundation

public protocol DeleteConsumerDataContract {
    func deleteConsumer(consumerId: Int, success: @escaping () -> Void, failure: @escaping (DeleteConsumerError) -> Void)
}
