//
//  AddConsumercontract.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 22/02/23.
//

import Foundation

public protocol AddConsumerDataContract {
    func addConsumer(consumer: Consumer, success: @escaping () -> Void, failure: @escaping (AddConsumerError) -> Void)
}
