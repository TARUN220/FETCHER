//
//  Admin.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 22/02/23.
//

import Foundation

public class Admin: User {
    public override init(id: Int, name: String, emailId: String, password: String, mobileNumber: String? = nil, pinCode: PinCode? = nil) {
        super.init(id: id, name: name, emailId: emailId, password: password)
    }
}
