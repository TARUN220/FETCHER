//
//  Service.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 22/02/23.
//

import Foundation

public struct Service {
    public var id: Int
    public var dateAndTime: String
    public var consumer: Consumer
    public var serviceProvider: ServiceProvider
    public var description: String
    public var consumerStatus: ConsumerState?
    public var serviceProviderStatus: ServiceProviderState?
    public var serviceStatus: ServiceState?
    public var approximateTimeInMinutes: String?
    public var amount: String?
    public var rating: String?
    public init(id: Int, dateAndTime: String, consumer: Consumer, serviceProvider: ServiceProvider, description: String, consumerStatus: ConsumerState? = .offline, serviceProviderStatus: ServiceProviderState? = .offline, serviceStatus: ServiceState? = .offline, approximateTimeInMinutes: String? = nil, amount: String? = "0", rating: String? = "0.0") {
        self.id = id
        self.dateAndTime = dateAndTime
        self.consumer = consumer
        self.serviceProvider = serviceProvider
        self.consumerStatus = consumerStatus
        self.serviceProviderStatus = serviceProviderStatus
        self.serviceStatus = serviceStatus
        self.description = description
        self.approximateTimeInMinutes = approximateTimeInMinutes
        self.amount = amount
        self.rating = rating
    }
}

public enum ConsumerState: String {
    case offline
    case requested
    case accepted
    case declined
    var status: String {
        self.rawValue
    }
}

public enum ServiceProviderState: String {
    case offline
    case accepted
    case declined
    var status: String {
        self.rawValue
    }
}

public enum ServiceState: String {
    case offline
    case booked
    case declined
    var status: String {
        self.rawValue
    }
}
