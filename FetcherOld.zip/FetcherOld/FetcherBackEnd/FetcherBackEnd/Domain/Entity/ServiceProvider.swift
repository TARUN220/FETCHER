//
//  ServiceProvider.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 22/02/23.
//

import Foundation

public class ServiceProvider: User {
    public var role: ServiceProviderRole
    public var experience: String
    public init(id: Int, name: String, emailId: String, password: String, mobileNumber: String? = nil, pinCode: PinCode? = nil, role: ServiceProviderRole, experience: String) {
        self.role = role
        self.experience = experience

        super.init(id: id, name: name, emailId: emailId, password: password, mobileNumber: mobileNumber, pinCode: pinCode)
    }
}
