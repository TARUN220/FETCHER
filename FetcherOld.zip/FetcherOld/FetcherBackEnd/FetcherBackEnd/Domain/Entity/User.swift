//
//  User.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 22/02/23.
//

import Foundation

public class User {
    public var id: Int
    public var name: String
    public var emailId: String
    public var password: String
    public var mobileNumber: String?
    public var pinCode: PinCode?
    public init(id: Int, name: String, emailId: String, password: String, mobileNumber: String? = nil, pinCode: PinCode? = nil) {
        self.id = id
        self.name = name
        self.emailId = emailId
        self.password = password
        self.mobileNumber = mobileNumber
        self.pinCode = pinCode
    }
}
