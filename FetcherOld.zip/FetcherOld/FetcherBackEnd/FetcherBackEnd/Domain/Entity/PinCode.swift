//
//  Pin.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 07/03/23.
//

import Foundation

public struct PinCode {
    public var id: Int
    public var pinCode: String
    public var newPinCode: Bool?
    public init(id: Int, pinCode: String, newPinCode: Bool? = false) {
        self.id = id
        self.pinCode = pinCode
        self.newPinCode = newPinCode
    }
}
