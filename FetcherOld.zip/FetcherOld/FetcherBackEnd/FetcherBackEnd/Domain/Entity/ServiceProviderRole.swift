//
//  ServiceProviderRole.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 22/02/23.
//

import Foundation

public struct ServiceProviderRole {
    public var id: Int
    public var role: String
    public var newRole: Bool?
    public init(id: Int, role: String, newRole: Bool? = false) {
        self.id = id
        self.role = role
        self.newRole = newRole
    }
}
