//
//  Database.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 22/02/23.
//

import Foundation
import SQLite3

public struct Column {
    let name: String
    let type: String
    var primaryKey: Bool = false
    var autoIncrement: Bool = false
}

public class Database {
    var db: OpaquePointer?
    
    init() {
        do {
            let filepath = try FileManager.default.url(for: .documentDirectory, in: .allDomainsMask, appropriateFor: nil, create: false).appendingPathComponent("Fetcher007.sqlite")
            let path = filepath.path
            if sqlite3_open_v2(path, &db, SQLITE_OPEN_CREATE | SQLITE_OPEN_READWRITE | SQLITE_OPEN_FULLMUTEX, nil) == SQLITE_OK {
//                print("Opened")
//                print("PATH: \(path)\n")
//                print(db!)
            }
        }
        catch {
            print("Error..")
        }
    }
    
    func create(tableName: String, columns: [Column]) {
        var tableTypes: String = ""
        
        for column in columns {
            tableTypes += column.name + " " + column.type
            if column.primaryKey == true {
                tableTypes += " PRIMARY KEY "
            }
            if column.autoIncrement == true {
                tableTypes += " AUTOINCREMENT "
            }
            tableTypes += ", "
        }
        
        let tableQuery = "CREATE TABLE IF NOT EXISTS " + tableName + " (" + tableTypes.dropLast(2) + ")"
//        print(tableQuery)
        if sqlite3_exec(db, tableQuery, nil, nil, nil) == SQLITE_OK {
//            print("Done")
        }

    }
    
    func addValue(tableName: String, columns: [Column], values: [String: Any]) -> Bool {
        
        var columnNames: String = ""
        var columnValue: String = ""
//        print("Column: ", columns)
//        print("Values: ", values)
        for column in columns {
            if column.autoIncrement == true {
                continue
            }
            columnNames += column.name + ", "
//            print("Column Name: ", columnNames)
//            print("columnValue: ", columnValue)
            if column.type == "TEXT" {
                
                columnValue += "\"" + String(values[column.name] as! String) + "\", "
            }
            else if column.type == "INTEGER" {
                columnValue += String(values[column.name] as! Int) + ", "
            }
            
        }
        let query = "INSERT INTO " + tableName + "(\(columnNames.dropLast(2))) " + "VALUES (\(columnValue.dropLast(2)))"
//        print(query)
        if sqlite3_exec(self.db, query, nil, nil, nil) == SQLITE_OK {
            
            return true
        }
        else {
//            print("No")
            return false
        }
    }
    
    func getData(tableName: String, column: [Column], columnName: String = "", columnValue: String = "") -> [[String: Any]] {
        var query = ""
        var getQuery1 = ""
        var getQuery: String = ""
        getQuery = "SELECT * FROM " + tableName
        if columnName != "" {
            if columnName.contains(",") {
                let columnNameArray: [String] = columnName.components(separatedBy: ",")
                let columnValueArray: [String] = columnValue.components(separatedBy: ",")
                query += " WHERE "
//                print("qq: \(query)")
                for i in 0..<columnNameArray.count {
                    query += columnNameArray[i] + " = \"" + columnValueArray[i] + "\" AND "
//                    print("qq: \(query)")
                }
                getQuery += query.dropLast(5)
                
            } else {
                query += " WHERE " + columnName + " = \"" + columnValue + "\""
                getQuery += query
            }
        }
        getQuery1 += getQuery
//        print("getQ1: ", getQuery1)
//        print("getQ: ", getQuery)
//        print("q: ", query)
        var selectStatementPointer: OpaquePointer?
        var result: [[String: Any]] = []
//        print("s0")
        if sqlite3_prepare_v2(self.db, getQuery, -1, &selectStatementPointer, nil) == SQLITE_OK {
//            print("s1")
            while sqlite3_step(selectStatementPointer) == SQLITE_ROW {
                var rowValue: [String: Any] = [: ]
//                print("colVAL \(columnValue)")
//                for (_, col) in column.enumerated() {
//                    print("col.name: \(col.name)")
//                    print("col.val: \(columnValue)")
//                }
                for (index, column) in column.enumerated() {
                    if column.type == "INTEGER" {
                        rowValue[column.name] = Int(sqlite3_column_int(selectStatementPointer, Int32(index)))
//                        print("row val1", rowValue[column.name]!)
                    }
                    else if column.type == "TEXT" {
                        rowValue[column.name] = String(cString: sqlite3_column_text(selectStatementPointer, Int32(index)))
//                        print("row val2", rowValue[column.name]!)
                    }
                }
                result.append(rowValue)
            }
            sqlite3_finalize(selectStatementPointer)
        }
//        print(result)
        return result
    }
    
    func updateValue(tableName: String, columns: [Column], values: [String: Any], id: Int) -> Bool {
        var columnValue: String = ""
        for column in columns {
            if values[column.name] != nil {
                if column.type == "TEXT" {
                    columnValue += " \(column.name) = \"\(values[column.name] as! String)\", "
                }
                else if column.type == "INTEGER" {
                    columnValue += " \(column.name) = \(values[column.name] as! Int), "
                }
            }
        }
        let query = "UPDATE \(tableName) SET \(columnValue.dropLast(2)) WHERE id = \(id)"
        if sqlite3_exec(self.db, query, nil, nil, nil) == SQLITE_OK {
            return true
        }
        else {
            return false
        }
    }
    
    func deleteValue(tableName: String, columnName: String, columnValue: String) -> Bool {
        
        var deleteQuery = "DELETE FROM \(tableName) WHERE "
        var deleteStatement: OpaquePointer?
        var deleteQuery1: String = ""
        
        if columnName.contains(",") {
            let columnNameArray: [String] = columnName.components(separatedBy: ",")
            let columnValueArray: [String] = columnValue.components(separatedBy: ",")
            for i in 0..<columnNameArray.count {
                deleteQuery += columnNameArray[i] + " = \"" + columnValueArray[i] + "\" AND "
//                print("qq: \(deleteQuery)")
            }
            deleteQuery1 += deleteQuery.dropLast(5)
            
        }
        else {
            deleteQuery += columnName + " = \"" + columnValue + "\""
            deleteQuery1 += deleteQuery
        }
//        print("delQ: \(deleteQuery1)")
        if sqlite3_prepare_v2(db, deleteQuery1, -1, &deleteStatement, nil) == SQLITE_OK {

            if sqlite3_step(deleteStatement) == SQLITE_DONE {
                return true
            } else {
                return false
            }
        }
        sqlite3_finalize(deleteStatement)
        return false
    }
}

