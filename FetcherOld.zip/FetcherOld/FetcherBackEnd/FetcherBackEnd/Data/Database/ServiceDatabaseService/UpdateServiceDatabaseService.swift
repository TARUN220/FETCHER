//
//  UpdateServiceDatabaseService.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 09/03/23.
//

import Foundation

public class UpdateServiceDatabaseService: ServiceDatabaseService {
    public override init() {
        
    }
}

extension UpdateServiceDatabaseService: UpdateServiceDatabaseContract {
 
    public func updateService(newValues: [String: Any], serviceId: Int, success: @escaping () -> Void, failure: @escaping (String) -> Void) {
        
        let result = database.updateValue(tableName: "service", columns: serviceDatabaseColumn, values: newValues, id: serviceId)
        if result {
            success()
        }

        else {
            failure("Wrong Value")
        }
    }
    
}
