//
//  DeleteServiceDatabaseService.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 13/03/23.
//

import Foundation

public class DeleteServiceDatabaseService: ServiceDatabaseService {
    public override init() {
        
    }
}

extension DeleteServiceDatabaseService: DeleteServiceDatabaseContract {
 
    public func deleteService(columnName: String, columnValue: Any, success: @escaping () -> Void, failure: @escaping (String) -> Void) {
        
        var value: String?
        if let str = columnValue as? String {
            value = str
       }
        if let str = columnValue as? Int {
            value = String(str)
        }
        
        let result = database.deleteValue(tableName: "service", columnName: columnName, columnValue: value!)
        if result {
            success()
        }
        else {
            failure("Wrong Value")
        }
    }
    
}
