//
//  NewServiceDatabaseService.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 08/03/23.
//

import Foundation

public class NewServiceDatabaseService: ServiceDatabaseService {
    public override init() {

    }
}

extension NewServiceDatabaseService: NewServiceDatabaseContract {
    public func newService(service: Service, success: @escaping () -> Void, failure: @escaping () -> Void) {
        
        var value: [String: Any] = [: ]
        value["id"] = service.id
        value["consumerId"] = service.consumer.id
        value["serviceRoleNeeded"] = service.serviceProvider.role.role
        value["serviceDescription"] = service.description
        value["serviceDateAndTime"] = service.dateAndTime
        value["consumerStatus"] = service.consumerStatus?.rawValue
        value["serviceProviderId"] = service.serviceProvider.id
        value["serviceProviderStatus"] = service.serviceProviderStatus?.rawValue
        value["serviceApproximateTimeInMinutes"] = service.approximateTimeInMinutes
        value["serviceApproximateAmount"] = service.amount
        value["serviceStatus"] = service.serviceStatus?.rawValue

//        print(value)
        let result = database.addValue(tableName: "service", columns: serviceDatabaseColumn, values: value)
        if result {
            success()
        }
        else {
            failure()
        }
    }
}
