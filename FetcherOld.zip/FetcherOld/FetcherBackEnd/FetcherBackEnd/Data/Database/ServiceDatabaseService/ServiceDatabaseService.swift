//
//  ServiceDatabaseService.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 08/03/23.
//

import Foundation

public class ServiceDatabaseService {
    
    let columnName: [String] = ["id", "consumerId", "serviceRoleNeeded", "serviceDescription", "serviceDateAndTime", "consumerStatus", "serviceProviderId", "serviceProviderStatus", "serviceApproximateTimeInMinutes", "serviceApproximateAmount", "serviceStatus"]
    let columnType: [String] = ["INTEGER", "INTEGER", "TEXT", "TEXT", "TEXT", "TEXT", "INTEGER", "TEXT", "TEXT", "TEXT", "TEXT"]
    let primaryKey: [String] = ["id"]
    let autoIncrement: [String] = ["id"]
    let database: Database
    public var serviceDatabaseColumn: [Column] = []
    
    init() {
        
        for index in 0..<columnName.count {
            var isPrimaryKey: Bool = false
            var isAutoIncrement: Bool = false
            if primaryKey.contains(columnName[index]) {
                isPrimaryKey = true
            }
            if autoIncrement.contains(columnName[index]) {
                isAutoIncrement = true
            }
            let inst = Column(name: columnName[index], type: columnType[index], primaryKey: isPrimaryKey, autoIncrement: isAutoIncrement)
            self.serviceDatabaseColumn.append(inst)
        }
        database = Database()
        database.create(tableName: "service", columns: serviceDatabaseColumn)
    }
    
}
