//
//  SearchServiceDatabaseService.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 09/03/23.
//

import Foundation

public final class SearchServiceDatabaseService: ServiceDatabaseService {
    public override init() {
        
    }
}

extension SearchServiceDatabaseService: SearchServiceDatabaseContract {
    public func searchService(columnName: String, columnValue: Any, success: @escaping ([Service]) -> Void, failure: @escaping () -> Void) {
        var value: String?
        if let str = columnValue as? String {
            value = str
        }
        
        if let str = columnValue as? Int {
            value = String(str)
        }
        
//        print("Search Service databse service")
        
        let result = database.getData(tableName: "service", column: serviceDatabaseColumn, columnName: columnName, columnValue: value!)
        var serviceList: [Service] = []
        
        for service in result {
            //FOR CONSUMER INSTANCE
            var temp = service["consumerId"] as! Int
            let consumerDatabaseService = ConsumerDatabaseService()
            let consumer = database.getData(tableName: "consumer7", column: consumerDatabaseService.consumerDatabaseColumn, columnName: "id", columnValue: String(temp))
            var consumer1: Consumer?
            for consumer3 in consumer {
                var pinCodeId = consumer3["pinCodeId"] as! Int
                let pinCodeDatabaseService = PinCodeDatabaseService()
                let pinCode = database.getData(tableName: "pinCode", column: pinCodeDatabaseService.pinCodeDatabaseColumn, columnName: "id", columnValue: String(pinCodeId))
                var pinCode1: PinCode?
//                    var pinCode2: String = ""
                for pinCodeInstance in pinCode {
                    pinCode1 = PinCode(id: pinCodeInstance["id"] as! Int, pinCode: pinCodeInstance["pinCode"] as! String)
//                        pinCode2 = pinCode1!.pinCode
                }
                
                consumer1 = Consumer(id: consumer3["id"] as! Int, name: consumer3["name"] as! String , emailId: consumer3["emailId"] as! String, password: consumer3["password"] as! String, mobileNumber: consumer3["mobileNumber"] as? String, pinCode: pinCode1)
            }
            
            //FOR SERVICE PROVIDER INSTANCE
            temp = service["serviceProviderId"] as! Int
            let serviceProviderDatabaseService = ServiceProviderDatabaseService()
            let serviceProvider = database.getData(tableName: "serviceProvider7", column: serviceProviderDatabaseService.serviceProviderDatabaseColumn, columnName: "id", columnValue: String(temp))
            var serviceProvider1: ServiceProvider?
            for serviceProvider3 in serviceProvider {
                var pinCodeId = serviceProvider3["pinCodeId"] as! Int
                let pinCodeDatabaseService = PinCodeDatabaseService()
                let pinCode = database.getData(tableName: "pinCode", column: pinCodeDatabaseService.pinCodeDatabaseColumn, columnName: "id", columnValue: String(pinCodeId))
                var pinCode1: PinCode?
//                    var pinCode2: String = ""
                for pinCodeInstance in pinCode {
                    pinCode1 = PinCode(id: pinCodeInstance["id"] as! Int, pinCode: pinCodeInstance["pinCode"] as! String)
//                        pinCode2 = pinCode1!.pinCode
                }
                
                temp = serviceProvider3["serviceProviderRoleId"] as! Int
//                    print("temp", temp)
                
                let serviceProviderRoleDatabaseService = ServiceProviderRoleDatabaseService()
                let role = database.getData(tableName: "service_Provider_Role1", column: serviceProviderRoleDatabaseService.serviceProviderRoleDatabaseColumn, columnName: "id", columnValue: String(temp))
                var role2: String = ""
                var role3: ServiceProviderRole?
                for role1 in role {
                    role3 = ServiceProviderRole(id: role1["id"] as! Int, role: role1["role"] as! String)
//                        role2 = role3!.role
                }
                
                serviceProvider1 = ServiceProvider(id: serviceProvider3["id"] as! Int, name: serviceProvider3["name"] as! String , emailId: serviceProvider3["emailId"] as! String, password: serviceProvider3["password"] as! String, mobileNumber: serviceProvider3["mobileNumber"] as? String, pinCode: pinCode1, role: role3!, experience: serviceProvider3["experience"] as! String)
            }
            
            var consumerStatus1: ConsumerState?
            if service["consumerStatus"] as! String == "requested" {
                consumerStatus1 = ConsumerState.requested
            } else if service["consumerStatus"] as! String == "accepted" {
                consumerStatus1 = ConsumerState.accepted
            } else {
                consumerStatus1 = ConsumerState.offline
            }
            
            var serviceProviderStatus1: ServiceProviderState?
            if service["serviceProviderStatus"] as! String == "accepted" {
                serviceProviderStatus1 = ServiceProviderState.accepted
            } else if service["serviceProviderStatus"] as! String == "declined" {
                serviceProviderStatus1 = ServiceProviderState.declined
            } else {
                serviceProviderStatus1 = ServiceProviderState.offline
            }
            
            var serviceStatus1: ServiceState?
            if service["serviceStatus"] as! String == "booked" {
                serviceStatus1 = ServiceState.booked
            } else if service["serviceStatus"] as! String == "declined" {
                serviceStatus1 = ServiceState.declined
            } else {
                serviceStatus1 = ServiceState.offline
            }
            
            let serviceInstance = Service(id: service["id"] as! Int, dateAndTime: service["serviceDateAndTime"] as! String, consumer: consumer1!, serviceProvider: serviceProvider1!, description: service["serviceDescription"] as! String, consumerStatus: consumerStatus1!, serviceProviderStatus: serviceProviderStatus1 , serviceStatus: serviceStatus1, approximateTimeInMinutes: service["serviceApproximateTimeInMinutes"] as? String, amount: service["serviceApproximateAmount"] as? String)
            serviceList.append(serviceInstance)
//            print("ser Inst: ",serviceInstance)
        }
        
        if serviceList.count > 0 {
            success(serviceList)
        }
        else {
            failure()
        }
    }
}
