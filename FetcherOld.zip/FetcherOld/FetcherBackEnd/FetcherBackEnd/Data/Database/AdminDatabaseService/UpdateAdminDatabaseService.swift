//
//  UpdateAdminDatabaseService.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 14/03/23.
//

import Foundation

public class UpdateAdminDatabaseService: AdminDatabaseService {
    public override init() {
        
    }
}

extension UpdateAdminDatabaseService: UpdateAdminDatabaseContract {
 
    public func updateAdmin(newValues: [String: Any], adminId: Int, success: @escaping () -> Void, failure: @escaping (String) -> Void) {
        
        let result = database.updateValue(tableName: "admin", columns: adminDatabaseColumn, values: newValues, id: adminId)
        if result {
            success()
        }
        
        else {
            failure("Wrong Value")
        }
    }
    
}
