//
//  SearchAdminDatabaseService.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 01/03/23.
//

import Foundation

public final class SearchAdminDatabaseService: AdminDatabaseService {
    public override init() {
        
    }
}

extension SearchAdminDatabaseService: SearchAdminDatabaseContract {
    public func searchAdmin(columnName: String, columnValue: Any, success: @escaping ([Admin]) -> Void, failure: @escaping () -> Void) {
        var value: String?
        if let str = columnValue as? String {
            value = str
        }
        else if let str = columnValue as? Int {
            value = String(str)
        }
//        print("Admin Database Service..")
        let result = database.getData(tableName: "admin", column: adminDatabaseColumn, columnName: columnName, columnValue: value!)
        var adminDatabaseList: [Admin] = []
        for admin in result {
            let adminInstance = Admin(id: admin["id"] as! Int, name: admin["name"] as! String, emailId: admin["emailId"] as! String, password: admin["password"] as! String)
            adminDatabaseList.append(adminInstance)
        }
        
        if adminDatabaseList.count > 0 {
            success(adminDatabaseList)
        }
        else {
            failure()
        }
    }
    
    
    
    
}
