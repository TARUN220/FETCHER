//
//  AddPinDatabaseService.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 07/03/23.
//

import Foundation

public class AddPinCodeDatabaseService: PinCodeDatabaseService {
    public override init() {
        
    }
}

extension AddPinCodeDatabaseService: AddPinCodeDatabaseContract {
    public func addPinCode(pinCode: PinCode, success: @escaping () -> Void, failure: @escaping () -> Void) {
        var value: [String: Any] = [: ]
        if pinCode.newPinCode != true {
            value["id"] = pinCode.id
            value["pinCode"] = pinCode.pinCode
            value["permission"] = "allowed"
        }
        else {
            value["id"] = pinCode.id
            value["pinCode"] = pinCode.pinCode
            value["permission"] = "requested"
        }
        let result = database.addValue(tableName: tableName, columns: pinCodeDatabaseColumn, values: value)
        if result {
            success()
        }
        else {
            failure()
        }
    }
    
    
}
