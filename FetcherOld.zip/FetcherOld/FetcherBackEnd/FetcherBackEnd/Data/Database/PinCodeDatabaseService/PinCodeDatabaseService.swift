//
//  PinDatabaseService.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 07/03/23.
//

import Foundation

public class PinCodeDatabaseService {
    public let columnName: [String] = ["id", "pinCode", "permission"]
    public let columnType: [String] = ["INTEGER", "TEXT", "TEXT"]
    public let primaryKey: [String] = ["id"]
    public let autoIncrement: [String] = ["id"]
    
    let database: Database
    public var pinCodeDatabaseColumn: [Column] = []
    
    var tableName: String
    var firstTime: Bool = true
    
    public init() {
        for index in 0..<columnName.count {
            var isPrimaryKey: Bool = false
            var isAutoIncrement: Bool = false
            if primaryKey.contains(columnName[index]) {
                isPrimaryKey = true
            }
            if autoIncrement.contains(columnName[index]) {
                isAutoIncrement = true
            }
            let instance = Column(name: columnName[index], type: columnType[index], primaryKey: isPrimaryKey, autoIncrement: isAutoIncrement)
            pinCodeDatabaseColumn.append(instance)
        }
        database = Database()
        tableName = "pinCode"
        database.create(tableName: tableName, columns: pinCodeDatabaseColumn)

    }
    
}
