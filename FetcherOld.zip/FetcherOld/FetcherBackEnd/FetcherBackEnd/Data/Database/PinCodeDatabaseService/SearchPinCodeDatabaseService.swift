//
//  SearchPinDatabaseService.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 07/03/23.
//

import Foundation

public final class SearchPinCodeDatabaseService: PinCodeDatabaseService {
    public override init() {
        
    }
}

extension SearchPinCodeDatabaseService: SearchPinCodeDatabaseContract {
    public func searchPinCode(columnName: String, columnValue: Any, success: @escaping ([PinCode]) -> Void, failure: @escaping () -> Void) {
        var value: String?
        if let str = columnValue as? String {
            value = str
        }
        
        if let str = columnValue as? Int {
            value = String(str)
        }
        
//        print("Search PinCode databse service")
        
        let result = database.getData(tableName: tableName, column: pinCodeDatabaseColumn, columnName: columnName, columnValue: value!)
        
        var pinCodeList: [PinCode] = []
        for pinCode in result {
            let pinCodeInstance = PinCode(id: pinCode["id"] as! Int, pinCode: pinCode["pinCode"] as! String)
            pinCodeList.append(pinCodeInstance)
        }
        
        if pinCodeList.count > 0 {
            success(pinCodeList)
        }
        else {
            failure()
        }
    }
    
    
}
