//
//  PinListDatabaseService.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 07/03/23.
//

import Foundation

public class PinCodeListDatabaseService: PinCodeDatabaseService {
    public override init() {

    }
}

extension PinCodeListDatabaseService: PinCodeListDatabaseContract {
    
    public func getPinCodeList(success: @escaping ([PinCode]) -> Void, failure: @escaping () -> Void) {
        let result = database.getData(tableName: tableName, column: pinCodeDatabaseColumn)
//        print("res: \(result)")
        var pinCodeList: [PinCode] = []
        for pinCode in result {
            if pinCode["permission"] as? String == "allowed" {
                let pinCodeInstance = PinCode(id: pinCode["id"] as! Int, pinCode: pinCode["pinCode"] as! String)
                pinCodeList.append(pinCodeInstance)
            }
        }
        
        if pinCodeList.count > 0 {
            success(pinCodeList)
        }
        else {
            failure()
        }
    }
    
}
