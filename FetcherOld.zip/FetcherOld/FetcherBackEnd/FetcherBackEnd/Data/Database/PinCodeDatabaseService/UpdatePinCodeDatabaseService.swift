//
//  UpdatePinCodeDatabaseService.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 13/03/23.
//

import Foundation

public class UpdatePinCodeDatabaseService: PinCodeDatabaseService {
    public override init() {
        
    }
}

extension UpdatePinCodeDatabaseService: UpdatePinCodeDatabaseContract {
 
    public func updatePinCode(newValues: [String: Any], pinCodeId: Int, success: @escaping () -> Void, failure: @escaping (String) -> Void) {
        
        let result = database.updateValue(tableName: tableName, columns: pinCodeDatabaseColumn, values: newValues, id: pinCodeId)
        if result {
            success()
        }

        else {
            failure("Wrong Value")
        }
    }
    
}
