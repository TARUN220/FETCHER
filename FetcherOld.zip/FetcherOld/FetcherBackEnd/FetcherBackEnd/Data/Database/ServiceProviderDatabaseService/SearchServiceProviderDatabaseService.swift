//
//  SearchServiceProviderDatabaseService.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 03/03/23.
//

import Foundation

public final class SearchServiceProviderDatabaseService: ServiceProviderDatabaseService {
    public override init() {
        
    }
}

extension SearchServiceProviderDatabaseService: SearchServiceProviderDatabaseContract {
    public func searchServiceProvider(columnName: String, columnValue: Any, success: @escaping ([ServiceProvider]) -> Void, failure: @escaping () -> Void) {
        var value: String?
        if let str = columnValue as? String {
            value = str
        }
        
        if let str = columnValue as? Int {
            value = String(str)
        }
        
//        print("Search ServiceProvider databse service")
        
        let result = database.getData(tableName: "serviceProvider7", column: serviceProviderDatabaseColumn, columnName: columnName, columnValue: value!)
//        print("res: \(result)")
        var serviceProviderList: [ServiceProvider] = []
        for serviceProvider in result {
//            print("1:", serviceProvider)
            var temp = serviceProvider["serviceProviderRoleId"] as! Int
//            print("temp", temp)
            
            let serviceProviderRoleDatabaseService = ServiceProviderRoleDatabaseService()
            let role = database.getData(tableName: "service_Provider_Role1", column: serviceProviderRoleDatabaseService.serviceProviderRoleDatabaseColumn, columnName: "id", columnValue: String(temp))
//            print("role", role)
            var role2: String = ""
            var role3: ServiceProviderRole?
            for role1 in role {
                role3 = ServiceProviderRole(id: role1["id"] as! Int, role: role1["role"] as! String, newRole: false)
//                print("rr3 \(String(describing: role3))")
                role2 = role3!.role
            }
            
            temp = serviceProvider["pinCodeId"] as! Int
            let pinCodeDatabaseService = PinCodeDatabaseService()
            let pinCode = database.getData(tableName: "pinCode", column: pinCodeDatabaseService.pinCodeDatabaseColumn, columnName: "id", columnValue: String(temp))
            var pinCode1: PinCode?
            var pinCode2: String = ""
            for pinCodeInstance in pinCode {
                pinCode1 = PinCode(id: pinCodeInstance["id"] as! Int, pinCode: pinCodeInstance["pinCode"] as! String)
                pinCode2 = pinCode1!.pinCode
            }
            
            let serviceProviderInstance = ServiceProvider(id: serviceProvider["id"] as! Int, name: serviceProvider["name"] as! String, emailId: serviceProvider["emailId"] as! String, password: serviceProvider["password"] as! String, mobileNumber: serviceProvider["mobileNumber"] as? String, pinCode: pinCode1!, role: role3!, experience: serviceProvider["experience"] as! String)
//            print("sp: ", serviceProviderInstance)
            serviceProviderList.append(serviceProviderInstance)
        }
        
        if serviceProviderList.count > 0 {
            success(serviceProviderList)
        }
        else {
            failure()
        }
    }
    
    
}
