//
//  AddServiceProviderDatabaseService.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 02/03/23.
//

import Foundation

public class AddServiceProviderDatabaseService: ServiceProviderDatabaseService {
    public override init() {

    }
}

extension AddServiceProviderDatabaseService: AddServiceProviderDatabaseContract {
    public func addServiceProvider(serviceProvider: ServiceProvider, success: @escaping () -> Void, failure: @escaping () -> Void) {
        var value: [String: Any] = [: ]
//        print(serviceProvider.mobileNumber)
        value["id"] = serviceProvider.id
        value["name"] = serviceProvider.name
        value["emailId"] = serviceProvider.emailId
        value["password"] = serviceProvider.password
        value["mobileNumber"] = serviceProvider.mobileNumber
        value["pinCodeId"] = serviceProvider.pinCode?.id
        //"serviceProviderRoleId", "expirence", "rating"
        value["serviceProviderRoleId"] = serviceProvider.role.id
        value["experience"] = serviceProvider.experience
//        value["rating"] = serviceProvider.rating
        
        print(value)
        let result = database.addValue(tableName: "serviceProvider7", columns: serviceProviderDatabaseColumn, values: value)
        if result {
            success()
        }
        else {
            failure()
        }
    }
}
