//
//  ServiceProviderRoleDatabaseService.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 23/02/23.
//

import Foundation

public class ServiceProviderRoleDatabaseService {
    public let columnName: [String] = ["id", "role", "permission"]
    public let columnType: [String] = ["INTEGER", "TEXT", "TEXT"]
    public let primaryKey: [String] = ["id"]
    public let autoIncrement: [String] = ["id"]
    
    let database: Database
    public var serviceProviderRoleDatabaseColumn: [Column] = []
    
    var tableName: String
    var firstTime: Bool = true
    
    public init() {
        for index in 0..<columnName.count {
            var isPrimaryKey: Bool = false
            var isAutoIncrement: Bool = false
            if primaryKey.contains(columnName[index]) {
                isPrimaryKey = true
            }
            if autoIncrement.contains(columnName[index]) {
                isAutoIncrement = true
            }
            let instance = Column(name: columnName[index], type: columnType[index], primaryKey: isPrimaryKey, autoIncrement: isAutoIncrement)
            serviceProviderRoleDatabaseColumn.append(instance)
        }
        database = Database()
        tableName = "service_Provider_Role1"
        database.create(tableName: tableName, columns: serviceProviderRoleDatabaseColumn)

    }
    
}
