//
//  ServiceProviderListDatabaseService.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 02/03/23.
//

import Foundation

public class ServiceProviderRoleListDatabaseService: ServiceProviderRoleDatabaseService {
    public override init() {

    }
}

extension ServiceProviderRoleListDatabaseService: ServiceProviderRoleListDatabaseContract {
    public func getServiceProviderRoleList(success: @escaping ([ServiceProviderRole]) -> Void, failure: @escaping () -> Void) {
        let result = database.getData(tableName: tableName, column: serviceProviderRoleDatabaseColumn)
//        print("res : ", result)
        var serviceProviderRoleList: [ServiceProviderRole] = []
        for serviceProviderRole in result {
            if serviceProviderRole["permission"] as? String == "allowed" {
                let serviceProviderRoleInstance = ServiceProviderRole(id: serviceProviderRole["id"] as! Int, role: serviceProviderRole["role"] as! String, newRole: false)
                serviceProviderRoleList.append(serviceProviderRoleInstance)
//                print(serviceProviderRoleInstance)
            }
        }
        
        if serviceProviderRoleList.count > 0 {
            success(serviceProviderRoleList)
        }
        else {
            failure()
        }
    }
    
}
