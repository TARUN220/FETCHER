//
//  SearchServiceProviderRoleDatabaseService.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 02/03/23.
//

import Foundation

public final class SearchServiceProviderRoleDatabaseService: ServiceProviderRoleDatabaseService {
    public override init() {
        
    }
}

extension SearchServiceProviderRoleDatabaseService: SearchServiceProviderRoleDatabaseContract {
    public func searchServiceProviderRole(columnName: String, columnValue: Any, success: @escaping ([ServiceProviderRole]) -> Void, failure: @escaping () -> Void) {
        var value: String?
        if let str = columnValue as? String {
            value = str
        }
        
        if let str = columnValue as? Int {
            value = String(str)
        }
//
        
        
//        print("Search ServiceProviderRole databse service")
        
        let result = database.getData(tableName: tableName, column: serviceProviderRoleDatabaseColumn, columnName: columnName, columnValue: value!)
        
        var serviceProviderRoleList: [ServiceProviderRole] = []
        for serviceProviderRole in result {
            let serviceProviderRoleInstance = ServiceProviderRole(id: serviceProviderRole["id"] as! Int, role: serviceProviderRole["role"] as! String)
            serviceProviderRoleList.append(serviceProviderRoleInstance)
        }
        
        if serviceProviderRoleList.count > 0 {
            success(serviceProviderRoleList)
        }
        else {
            failure()
        }
    }
}
