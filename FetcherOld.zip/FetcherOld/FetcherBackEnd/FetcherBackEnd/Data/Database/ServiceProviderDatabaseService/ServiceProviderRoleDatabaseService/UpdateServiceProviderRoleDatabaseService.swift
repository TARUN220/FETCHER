//
//  UpdateServiceProviderRoleDatabaseServiceProviderRole.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 10/03/23.
//

import Foundation

public class UpdateServiceProviderRoleDatabaseService: ServiceProviderRoleDatabaseService {
    public override init() {
        
    }
}

extension UpdateServiceProviderRoleDatabaseService: UpdateServiceProviderRoleDatabaseContract {
 
    public func updateServiceProviderRole(newValues: [String: Any], serviceProviderRoleId: Int, success: @escaping () -> Void, failure: @escaping (String) -> Void) {
        
        let result = database.updateValue(tableName: tableName, columns: serviceProviderRoleDatabaseColumn, values: newValues, id: serviceProviderRoleId)
        if result {
            success()
        }

        else {
            failure("Wrong Value")
        }
    }
    
}
