//
//  AddServiceProviderRoleDatabaseService.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 23/02/23.
//

import Foundation

public class AddServiceProviderRoleDatabaseService: ServiceProviderRoleDatabaseService {
    public override init() {
        
    }
}

extension AddServiceProviderRoleDatabaseService: AddServiceProviderRoleDatabaseContract {
    public func addServiceProviderRole(serviceProviderRole: ServiceProviderRole, success: @escaping () -> Void, failure: @escaping () -> Void) {
        var value: [String: Any] = [: ]
        if serviceProviderRole.newRole != true {
            value["id"] = serviceProviderRole.id
            value["role"] = serviceProviderRole.role
            value["permission"] = "allowed"
        }
        else {
            value["id"] = serviceProviderRole.id
            value["role"] = serviceProviderRole.role
            value["permission"] = "requested"
        }
        let result = database.addValue(tableName: tableName, columns: serviceProviderRoleDatabaseColumn, values: value)
        if result {
            success()
        }
        else {
            failure()
        }
        
        
    }
    
    
}
