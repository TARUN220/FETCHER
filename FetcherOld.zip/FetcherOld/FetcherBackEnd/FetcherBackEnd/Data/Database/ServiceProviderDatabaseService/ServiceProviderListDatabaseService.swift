//
//  ServiceProviderListDatabaseService.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 08/03/23.
//

import Foundation

public class ServiceProviderListDatabaseService: ServiceProviderDatabaseService {
    public override init() {

    }
}

extension ServiceProviderListDatabaseService: ServiceProviderListDatabaseContract {
    public func getServiceProviderList(success: @escaping ([ServiceProvider]) -> Void, failure: @escaping () -> Void) {
        let result = database.getData(tableName: "serviceProvider7", column: serviceProviderDatabaseColumn)
        var serviceProviderList: [ServiceProvider] = []
        for serviceProvider in result {
            
            var temp = serviceProvider["serviceProviderRoleId"] as! Int
            
            let serviceProviderRoleDatabaseService = ServiceProviderRoleDatabaseService()
            let role = database.getData(tableName: "service_Provider_Role1", column: serviceProviderRoleDatabaseService.serviceProviderRoleDatabaseColumn, columnName: "id", columnValue: String(temp))
            var role2: String = ""
            var role3: ServiceProviderRole?
            for role1 in role {
                role3 = ServiceProviderRole(id: role1["id"] as! Int, role: role1["role"] as! String)
                role2 = role3!.role
            }
            
            temp = serviceProvider["pinCodeId"] as! Int
            let pinCodeDatabaseService = PinCodeDatabaseService()
            let pinCode = database.getData(tableName: "pinCode", column: pinCodeDatabaseService.pinCodeDatabaseColumn, columnName: "id", columnValue: String(temp))
            var pinCode1: PinCode?
            var pinCode2: String = ""
            for pinCodeInstance in pinCode {
                pinCode1 = PinCode(id: pinCodeInstance["id"] as! Int, pinCode: pinCodeInstance["pinCode"] as! String)
                pinCode2 = pinCode1!.pinCode
            }
            
            let serviceProviderInstance = ServiceProvider(id: serviceProvider["id"] as! Int, name: serviceProvider["name"] as! String, emailId: serviceProvider["emailId"] as! String, password: serviceProvider["password"] as! String, mobileNumber: serviceProvider["mobileNumber"] as? String, pinCode: pinCode1!, role: role3!, experience: serviceProvider["experience"] as! String)
            serviceProviderList.append(serviceProviderInstance)
        }
        
        if serviceProviderList.count > 0 {
            success(serviceProviderList)
        }
        else {
            failure()
        }
    }
    
}
