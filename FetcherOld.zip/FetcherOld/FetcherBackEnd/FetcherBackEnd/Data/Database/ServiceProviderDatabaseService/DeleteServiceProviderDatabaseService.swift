//
//  DeleteServiceProviderDatabaseService.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 13/03/23.
//

import Foundation
public class DeleteServiceProviderDatabaseService: ServiceProviderDatabaseService {
    public override init() {
        
    }
}

extension DeleteServiceProviderDatabaseService: DeleteServiceProviderDatabaseContract {
 
    public func deleteServiceProvider(serviceProviderId: Int, success: @escaping () -> Void, failure: @escaping (String) -> Void) {
        
        var result = database.deleteValue(tableName: "serviceProvider7", columnName: "id", columnValue: String(serviceProviderId))
        if result {
            success()
        }
        else {
            failure("Wrong Value")
        }
    }
    
}
