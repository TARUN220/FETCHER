//
//  UpdateServiceProviderDatabaseService.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 14/03/23.
//

import Foundation
public class UpdateServiceProviderDatabaseService: ServiceProviderDatabaseService {
    public override init() {
        
    }
}

extension UpdateServiceProviderDatabaseService: UpdateServiceProviderDatabaseContract {
 
    public func updateServiceProvider(newValues: [String: Any], serviceProviderId: Int, success: @escaping () -> Void, failure: @escaping (String) -> Void) {
        
        let result = database.updateValue(tableName: "serviceProvider7", columns: serviceProviderDatabaseColumn, values: newValues, id: serviceProviderId)
        if result {
            success()
        }
        
        else {
            failure("Wrong Value")
        }
    }
    
}
