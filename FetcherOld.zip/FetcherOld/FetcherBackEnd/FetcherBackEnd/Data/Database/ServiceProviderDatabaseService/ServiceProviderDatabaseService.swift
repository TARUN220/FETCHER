//
//  ServiceProviderDatabaseService.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 02/03/23.
//

import Foundation

public class ServiceProviderDatabaseService {
    let columnName: [String] = ["id", "name", "emailId", "password", "mobileNumber", "pinCodeId", "serviceProviderRoleId", "experience"]
    let columnType: [String] = ["INTEGER", "TEXT", "TEXT", "TEXT", "TEXT", "INTEGER", "INTEGER", "TEXT"]
    let primaryKey: [String] = ["id"]
    let autoIncrement: [String] = ["id"]
    let database: Database
    public var serviceProviderDatabaseColumn: [Column] = []
    
    init() {
        for index in 0..<columnName.count {
            var isPrimaryKey: Bool = false
            var isAutoIncrement: Bool = false
            if primaryKey.contains(columnName[index]) {
                isPrimaryKey = true
            }
            if autoIncrement.contains(columnName[index]) {
                isAutoIncrement = true
            }
            let instance = Column(name: columnName[index], type: columnType[index], primaryKey: isPrimaryKey, autoIncrement: isAutoIncrement)
            self.serviceProviderDatabaseColumn.append(instance)
        }
        database = Database()
//        print(serviceProviderDatabaseColumn)
        database.create(tableName: "serviceProvider7", columns: serviceProviderDatabaseColumn)
    }
}
