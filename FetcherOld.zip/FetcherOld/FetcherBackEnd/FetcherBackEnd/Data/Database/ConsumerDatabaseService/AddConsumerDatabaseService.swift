//
//  AddConsumerDatabaseService.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 22/02/23.
//

import Foundation

public class AddConsumerDatabaseService: ConsumerDatabaseService {
    public override init() {

    }
}

extension AddConsumerDatabaseService: AddConsumerDatabaseContract {
    public func addConsumer(consumer: Consumer, success: @escaping () -> Void, failure: @escaping () -> Void) {
        var value: [String: Any] = [: ]
        value["id"] = consumer.id
        value["name"] = consumer.name
        value["emailId"] = consumer.emailId
        value["password"] = consumer.password
        value["mobileNumber"] = consumer.mobileNumber
        value["pinCodeId"] = consumer.pinCode?.id
        let result = database.addValue(tableName: "consumer7", columns: consumerDatabaseColumn, values: value)
        print(result)
        if result {
            success()
            
        }
        else {
            failure()
        }
    }
}

