//
//  ConsumerDatabaseService.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 22/02/23.
//

import Foundation

public class ConsumerDatabaseService {
    let columnName: [String] = ["id", "name", "emailId", "password", "mobileNumber", "pinCodeId"]
    let columnType: [String] = ["INTEGER", "TEXT", "TEXT", "TEXT", "TEXT", "INTEGER"]
    let primaryKey: [String] = ["id"]
    let autoIncrement: [String] = ["id"]
    let database: Database
    public var consumerDatabaseColumn: [Column] = []
    
    init() {
        for index in 0..<columnName.count {
            var isPrimaryKey: Bool = false
            var isAutoIncrement: Bool = false
            if primaryKey.contains(columnName[index]) {
                isPrimaryKey = true
            }
            if autoIncrement.contains(columnName[index]) {
                isAutoIncrement = true
            }
            let instance = Column(name: columnName[index], type: columnType[index], primaryKey: isPrimaryKey, autoIncrement: isAutoIncrement)
            self.consumerDatabaseColumn.append(instance)
        }
        database = Database()
        database.create(tableName: "consumer7", columns: consumerDatabaseColumn)
    }
}
