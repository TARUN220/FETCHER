//
//  UpdateConsumerDatabaseService.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 22/02/23.
//

import Foundation

public class UpdateConsumerDatabaseService: ConsumerDatabaseService {
    public override init() {
        
    }
}

extension UpdateConsumerDatabaseService: UpdateConsumerDatabaseContract {
 
    public func updateConsumer(newValues: [String: Any], consumerId: Int, success: @escaping () -> Void, failure: @escaping (String) -> Void) {
        
        let result = database.updateValue(tableName: "consumer7", columns: consumerDatabaseColumn, values: newValues, id: consumerId)
        if result {
            success()
        }
        
        else {
            failure("Wrong Value")
        }
    }
    
}
