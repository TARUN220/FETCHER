//
//  DeleteConsumerDatabaseService.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 22/02/23.
//

import Foundation

public class DeleteConsumerDatabaseService: ConsumerDatabaseService {
    public override init() {
        
    }
}

extension DeleteConsumerDatabaseService: DeleteConsumerDatabaseContract {
 
    public func deleteConsumer(consumerId: Int, success: @escaping () -> Void, failure: @escaping (String) -> Void) {
        
        let result = database.deleteValue(tableName: "consumer7", columnName: "id", columnValue: String(consumerId))
        if result {
            success()
        }
        else {
            failure("Wrong Value")
        }
    }
    
}
