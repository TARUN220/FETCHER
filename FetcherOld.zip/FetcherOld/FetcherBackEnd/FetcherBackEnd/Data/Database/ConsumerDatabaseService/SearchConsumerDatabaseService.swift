//
//  SearchConsumerDatabaseService.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 22/02/23.
//

import Foundation

public final class SearchConsumerDatabaseService: ConsumerDatabaseService {
    public override init() {
        
    }
}

extension SearchConsumerDatabaseService: SearchConsumerDatabaseContract {
    public func searchConsumer(columnName: String, columnValue: Any, success: @escaping ([Consumer]) -> Void, failure: @escaping () -> Void) {
        var value: String?
        if let str = columnValue as? String {
            value = str
        }
        
        if let str = columnValue as? Int {
            value = String(str)
        }
        
//        print("Search consumer databse service")
        
        let result = database.getData(tableName: "consumer7", column: consumerDatabaseColumn, columnName: columnName, columnValue: value!)
        
        var consumerList: [Consumer] = []
        for consumer in result {
            
            let pinCodeId = consumer["pinCodeId"] as! Int
            let pinCodeDatabaseService = PinCodeDatabaseService()
            let pinCode = database.getData(tableName: "pinCode", column: pinCodeDatabaseService.pinCodeDatabaseColumn, columnName: "id", columnValue: String(pinCodeId))
            var pinCode1: PinCode?
            var pinCode2: String = ""
            for pinCodeInstance in pinCode {
                pinCode1 = PinCode(id: pinCodeInstance["id"] as! Int, pinCode: pinCodeInstance["pinCode"] as! String)
                pinCode2 = pinCode1!.pinCode
            }
            
            let consumerInstance = Consumer(id: consumer["id"] as! Int, name: consumer["name"] as! String, emailId: consumer["emailId"] as! String, password: consumer["password"] as! String, mobileNumber: consumer["mobileNumber"] as? String, pinCode: pinCode1)
            consumerList.append(consumerInstance)
        }
        
        if consumerList.count > 0 {
            success(consumerList)
        }
        else {
            failure()
        }
    }
    
    
}
