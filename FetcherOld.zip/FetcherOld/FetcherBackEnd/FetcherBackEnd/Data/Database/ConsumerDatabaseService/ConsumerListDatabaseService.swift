//
//  ConsumerListDatabaseService.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 22/02/23.
//

import Foundation

public class ConsumerListDatabaseService: ConsumerDatabaseService {
    public override init() {

    }
}

extension ConsumerListDatabaseService: ConsumerListDatabaseContract {
    public func getConsumerList(success: @escaping ([Consumer]) -> Void, failure: @escaping () -> Void) {
        let result = database.getData(tableName: "consumer7", column: consumerDatabaseColumn)
        var consumerList: [Consumer] = []
        for consumer in result {
            let temp = consumer["pinCodeId"] as! Int
            let pinCodeDatabaseService = PinCodeDatabaseService()
            let pinCode = database.getData(tableName: "pinCode", column: pinCodeDatabaseService.pinCodeDatabaseColumn, columnName: "id", columnValue: String(temp))
            var pinCode1: PinCode?
            var pinCode2: String = ""
            for pinCodeInstance in pinCode {
                pinCode1 = PinCode(id: pinCodeInstance["id"] as! Int, pinCode: pinCodeInstance["pinCode"] as! String)
                pinCode2 = pinCode1!.pinCode
            }
            
            let consumerInstance = Consumer(id: consumer["id"] as! Int, name: consumer["name"] as! String, emailId: consumer["emailId"] as! String, password: consumer["password"] as! String, mobileNumber: consumer["mobileNumber"] as? String, pinCode: pinCode1!)
            consumerList.append(consumerInstance)
        }
        
        if consumerList.count > 0 {
            success(consumerList)
        }
        else {
            failure()
        }
    }
    
}
