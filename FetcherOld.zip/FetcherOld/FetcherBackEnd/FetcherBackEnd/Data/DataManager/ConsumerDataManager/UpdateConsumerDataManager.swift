//
//  UpdateConsumerDataManager.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 14/03/23.
//

import Foundation
public final class UpdateConsumerDataManager: UpdateConsumerDataContract {
    
    var database: UpdateConsumerDatabaseContract
    
    public init(database: UpdateConsumerDatabaseContract) {
        self.database = database
    }
    
    public func updateConsumer(newValues: [String: Any], consumerId: Int, success: @escaping () -> Void, failure: @escaping (UpdateConsumerError) -> Void) {
        database.updateConsumer(newValues: newValues, consumerId: consumerId, success: { [weak self] () in
            self?.success(callback: success)}, failure: { [weak self] (message) in
                self?.failure(message: message, callback: failure)
            })
    }
    
    
    private func success(callback: () -> Void) {
        callback()
    }
    
    private func failure(message: String, callback: ((UpdateConsumerError) -> Void)) {
        let wrongInput = "Wrong Value"
        if message == wrongInput {
            let error = UpdateConsumerError(type: .wrongValue)
            callback(error)
        }
    }
}
