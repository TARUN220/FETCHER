//
//  DeleteConsumerDataManager.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 13/03/23.
//

import Foundation

public final class DeleteConsumerDataManager: DeleteConsumerDataContract {
    
    var database: DeleteConsumerDatabaseContract
    
    public init(database: DeleteConsumerDatabaseContract) {
        self.database = database
    }
    
    public func deleteConsumer(consumerId: Int, success: @escaping () -> Void, failure: @escaping (DeleteConsumerError) -> Void) {
        database.deleteConsumer(consumerId: consumerId, success: { [weak self] () in
            self?.success(callback: success)}, failure: { [weak self] (message) in
                self?.failure(message: message, callback: failure)
            })
    }
    
    
    private func success(callback: () -> Void) {
        callback()
    }
    
    private func failure(message: String, callback: ((DeleteConsumerError) -> Void)) {
        let wrongInput = "Wrong Value"
        if message == wrongInput {
            let error = DeleteConsumerError(type: .wrongValue)
            callback(error)
        }
    }
}
