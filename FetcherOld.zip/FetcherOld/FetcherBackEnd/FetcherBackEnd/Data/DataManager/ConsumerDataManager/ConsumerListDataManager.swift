//
//  ConsumerListDataManager.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 13/03/23.
//

import Foundation

public final class ConsumerListDataManager: GetConsumerListDataContract {
    
    var database: ConsumerListDatabaseContract
    public init(database: ConsumerListDatabaseContract) {
        self.database = database
    }
    
    public func getConsumerList(success: @escaping ([Consumer]) -> Void, failure: @escaping (GetConsumerListError) -> Void) {
        database.getConsumerList(success: { [weak self] (consumer) in
            self?.success(consumer: consumer, callback: success)
        }, failure: { [weak self] () in
            self?.failure(callback: failure)
        })
    }
    
    private func success(consumer: [Consumer], callback: ([Consumer]) -> Void) {
        callback(consumer)
    }
    
    private func failure(callback: ((GetConsumerListError) -> Void)) {
        let error = GetConsumerListError(type: .irresponsiveDatabase)
        callback(error)
    }
    
}
