//
//  ConsumerDatabaseContract.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 22/02/23.
//

import Foundation

public protocol AddConsumerDatabaseContract {
    func addConsumer(consumer: Consumer, success: @escaping () -> Void, failure: @escaping () -> Void)
}

public protocol ConsumerListDatabaseContract {
    func getConsumerList(success: @escaping ([Consumer]) -> Void, failure: @escaping () -> Void)
}

public protocol SearchConsumerDatabaseContract {
    func searchConsumer(columnName: String, columnValue: Any, success: @escaping ([Consumer]) -> Void, failure: @escaping () -> Void)
}

public protocol DeleteConsumerDatabaseContract {
    func deleteConsumer(consumerId: Int, success: @escaping ()-> Void, failure: @escaping (String) -> Void)
}

public protocol UpdateConsumerDatabaseContract {
    func updateConsumer(newValues: [String: Any], consumerId: Int, success: @escaping () -> Void, failure: @escaping (String) -> Void)
}
