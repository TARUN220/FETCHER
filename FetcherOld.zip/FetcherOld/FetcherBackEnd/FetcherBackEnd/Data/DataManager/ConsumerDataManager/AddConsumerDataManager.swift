//
//  AddConsumerDataManager.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 22/02/23.
//

import Foundation

public final class AddConsumerDataManager: AddConsumerDataContract {
    
    var database: AddConsumerDatabaseContract
    public init(database: AddConsumerDatabaseContract) {
        self.database = database
    }
    
    public func addConsumer(consumer: Consumer, success: @escaping () -> Void, failure: @escaping (AddConsumerError) -> Void) {
        database.addConsumer(consumer: consumer, success: { [weak self] () in
            self?.success(callback: success)
        }, failure: { [weak self] () in
            self?.failure(callback: failure)
        })
    }
    
    private func success(callback: () -> Void) {
        callback()
    }
    
    private func failure(callback: ((AddConsumerError) -> Void)) {
        let error = AddConsumerError(type: .irresponsiveDatabase)
        callback(error)
    }
}
