//
//  SearchConsumerDatamanager.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 24/02/23.
//

import Foundation

public class SearchConsumerDataManager: SearchConsumerDataContract {
    
    var database: SearchConsumerDatabaseContract
    var columnName: String
    var columnValue: Any
    
    public init(database: SearchConsumerDatabaseContract, columnName: String, columnValue: Any) {
        self.database = database
        self.columnName = columnName
        self.columnValue = columnValue
    }
    
    public func searchConsumer(success: @escaping ([Consumer]) -> Void, failure: @escaping (SearchConsumerError) -> Void) {
        database.searchConsumer(columnName: columnName, columnValue: columnValue, success: { [weak self] (consumer) in
            self?.success(consumer: consumer, callback: success)
        }, failure: { [weak self] () in
            self?.failure(callback: failure)
        })
    }
}

extension SearchConsumerDataManager {
    private func success(consumer: [Consumer], callback: (([Consumer]) -> Void)) {
        callback(consumer)
    }
    
    private func failure(callback: ((SearchConsumerError) -> Void)) {
        let error = SearchConsumerError(type: .irresponsiveDatabase)
        callback(error)
    }
}
