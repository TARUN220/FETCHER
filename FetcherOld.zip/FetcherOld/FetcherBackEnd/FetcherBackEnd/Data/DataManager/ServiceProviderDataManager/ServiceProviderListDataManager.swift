//
//  ServiceProviderListDataManager.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 08/03/23.
//

import Foundation

public final class ServiceProviderListDataManager: GetServiceProviderListDataContract {
    
    var database: ServiceProviderListDatabaseContract
    public init(database: ServiceProviderListDatabaseContract) {
        self.database = database
    }
    
    public func getServiceProviderList(success: @escaping ([ServiceProvider]) -> Void, failure: @escaping (GetServiceProviderListError) -> Void) {
        database.getServiceProviderList(success: { [weak self] (serviceProvider) in
            self?.success(serviceProvider: serviceProvider, callback: success)
        }, failure: { [weak self] () in
            self?.failure(callback: failure)
        })
    }
    
    private func success(serviceProvider: [ServiceProvider], callback: ([ServiceProvider]) -> Void) {
        callback(serviceProvider)
    }
    
    private func failure(callback: ((GetServiceProviderListError) -> Void)) {
        let error = GetServiceProviderListError(type: .irresponsiveDatabase)
        callback(error)
    }
    
}
