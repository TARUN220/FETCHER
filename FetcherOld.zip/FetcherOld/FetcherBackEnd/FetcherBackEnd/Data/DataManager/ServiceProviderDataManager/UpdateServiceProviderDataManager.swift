//
//  UpdateServiceProviderDataManager.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 14/03/23.
//

import Foundation
public final class UpdateServiceProviderDataManager: UpdateServiceProviderDataContract {
    
    var database: UpdateServiceProviderDatabaseContract
    
    public init(database: UpdateServiceProviderDatabaseContract) {
        self.database = database
    }
    
    public func updateServiceProvider(newValues: [String: Any], serviceProviderId: Int, success: @escaping () -> Void, failure: @escaping (UpdateServiceProviderError) -> Void) {
        database.updateServiceProvider(newValues: newValues, serviceProviderId: serviceProviderId, success: { [weak self] () in
            self?.success(callback: success)}, failure: { [weak self] (message) in
                self?.failure(message: message, callback: failure)
            })
    }
    
    
    private func success(callback: () -> Void) {
        callback()
    }
    
    private func failure(message: String, callback: ((UpdateServiceProviderError) -> Void)) {
        let wrongInput = "Wrong Value"
        if message == wrongInput {
            let error = UpdateServiceProviderError(type: .wrongValue)
            callback(error)
        }
    }
}
