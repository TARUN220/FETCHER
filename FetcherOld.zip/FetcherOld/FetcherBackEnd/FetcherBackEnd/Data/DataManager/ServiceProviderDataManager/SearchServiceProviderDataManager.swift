//
//  SearchServiceProviderDataManager.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 03/03/23.
//

import Foundation

public class SearchServiceProviderDataManager: SearchServiceProviderDataContract {
    
    var database: SearchServiceProviderDatabaseContract
    var columnName: String
    var columnValue: Any
    
    public init(database: SearchServiceProviderDatabaseContract, columnName: String, columnValue: Any) {
        self.database = database
        self.columnName = columnName
        self.columnValue = columnValue
    }
    
    public func searchServiceProvider(success: @escaping ([ServiceProvider]) -> Void, failure: @escaping (SearchServiceProviderError) -> Void) {
        database.searchServiceProvider(columnName: columnName, columnValue: columnValue, success: { [weak self] (serviceProvider) in
            self?.success(serviceProvider: serviceProvider, callback: success)
        }, failure: { [weak self] () in
            self?.failure(callback: failure)
        })
    }
}

extension SearchServiceProviderDataManager {
    private func success(serviceProvider: [ServiceProvider], callback: (([ServiceProvider]) -> Void)) {
        callback(serviceProvider)
    }
    
    private func failure(callback: ((SearchServiceProviderError) -> Void)) {
        let error = SearchServiceProviderError(type: .irresponsiveDatabase)
        callback(error)
    }
}
