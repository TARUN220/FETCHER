//
//  ServiceProviderRoleListDataManager.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 02/03/23.
//

import Foundation

public final class ServiceProviderRoleListDataManager: GetServiceProviderRoleListDataContract {
    
    var database: ServiceProviderRoleListDatabaseContract
    public init(database: ServiceProviderRoleListDatabaseContract) {
        self.database = database
    }
    
    public func getServiceProviderRoleList(success: @escaping ([ServiceProviderRole]) -> Void, failure: @escaping (GetServiceProviderRoleListError) -> Void) {
        database.getServiceProviderRoleList(success: { [weak self] (serviceProviderRole) in
            self?.success(serviceProviderRole: serviceProviderRole, callback: success)
        }, failure: { [weak self] () in
            self?.failure(callback: failure)
        })
    }
    
    private func success(serviceProviderRole: [ServiceProviderRole], callback: ([ServiceProviderRole]) -> Void) {
        callback(serviceProviderRole)
    }
    
    private func failure(callback: ((GetServiceProviderRoleListError) -> Void)) {
        let error = GetServiceProviderRoleListError(type: .irresponsiveDatabase)
        callback(error)
    }
    
}
