//
//  AddServiceProviderRoleDataManager.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 02/03/23.
//

import Foundation

public final class AddServiceProviderRoleDataManager: AddServiceProviderRoleDataContract {
    
    var database: AddServiceProviderRoleDatabaseContract
    public init(database: AddServiceProviderRoleDatabaseContract) {
        self.database = database
    }
    
    public func addServiceProviderRole(serviceProviderRole: ServiceProviderRole, success: @escaping () -> Void, failure: @escaping (AddServiceProviderRoleError) -> Void) {
        database.addServiceProviderRole(serviceProviderRole: serviceProviderRole, success: { [weak self] () in
            self?.success(callback: success)
        }, failure: { [weak self] () in
            self?.failure(callback: failure)
        })
    }
    
    private func success(callback: () -> Void) {
        callback()
    }
    
    private func failure(callback: ((AddServiceProviderRoleError) -> Void)) {
        let error = AddServiceProviderRoleError(type: .irresponsiveDatabase)
        callback(error)
    }
}
