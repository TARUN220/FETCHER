//
//  SearchSearchProviderRoleDataManager.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 02/03/23.
//

import Foundation

public class SearchServiceProviderRoleDataManager: SearchServiceProviderRoleDataContract {
    
    var database: SearchServiceProviderRoleDatabaseContract
    var columnName: String
    var columnValue: Any
    
    public init(database: SearchServiceProviderRoleDatabaseContract, columnName: String, columnValue: Any) {
        self.database = database
        self.columnName = columnName
        self.columnValue = columnValue
    }
    
    public func searchServiceProviderRole(success: @escaping ([ServiceProviderRole]) -> Void, failure: @escaping (SearchServiceProviderRoleError) -> Void) {
        database.searchServiceProviderRole(columnName: columnName, columnValue: columnValue, success: { [weak self] (serviceProviderRole) in
            self?.success(serviceProviderRole: serviceProviderRole, callback: success)
        }, failure: { [weak self] () in
            self?.failure(callback: failure)
        })
    }
}

extension SearchServiceProviderRoleDataManager {
    private func success(serviceProviderRole: [ServiceProviderRole], callback: (([ServiceProviderRole]) -> Void)) {
        callback(serviceProviderRole)
    }
    
    private func failure(callback: ((SearchServiceProviderRoleError) -> Void)) {
        let error = SearchServiceProviderRoleError(type: .irresponsiveDatabase)
        callback(error)
    }
}
