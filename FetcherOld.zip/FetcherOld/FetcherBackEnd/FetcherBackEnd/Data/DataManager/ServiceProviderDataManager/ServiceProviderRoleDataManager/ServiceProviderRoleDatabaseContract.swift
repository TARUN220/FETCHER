//
//  ServiceProviderRoleDatabaseContract.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 02/03/23.
//

import Foundation

public protocol AddServiceProviderRoleDatabaseContract {
    func addServiceProviderRole(serviceProviderRole: ServiceProviderRole, success: @escaping () -> Void, failure: @escaping () -> Void)
}

public protocol ServiceProviderRoleListDatabaseContract {
    func getServiceProviderRoleList(success: @escaping ([ServiceProviderRole]) -> Void, failure: @escaping () -> Void)
}

public protocol SearchServiceProviderRoleDatabaseContract {
    func searchServiceProviderRole(columnName: String, columnValue: Any, success: @escaping ([ServiceProviderRole]) -> Void, failure: @escaping () -> Void)
}

public protocol UpdateServiceProviderRoleDatabaseContract {
    func updateServiceProviderRole(newValues: [String: Any], serviceProviderRoleId: Int, success: @escaping () -> Void, failure: @escaping (String) -> Void)
}
