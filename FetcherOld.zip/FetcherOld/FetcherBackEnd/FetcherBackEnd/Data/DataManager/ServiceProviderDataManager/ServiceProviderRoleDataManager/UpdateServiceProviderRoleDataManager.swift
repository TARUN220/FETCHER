//
//  UpdateServiceProviderRoleDataManager.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 10/03/23.
//

import Foundation

public final class UpdateServiceProviderRoleDataManager: UpdateServiceProviderRoleDataContract {
    
    var database: UpdateServiceProviderRoleDatabaseContract
    
    public init(database: UpdateServiceProviderRoleDatabaseContract) {
        self.database = database
    }
    
    public func updateServiceProviderRole(newValues: [String: Any], serviceProviderRoleId: Int, success: @escaping () -> Void, failure: @escaping (UpdateServiceProviderRoleError) -> Void) {
        database.updateServiceProviderRole(newValues: newValues, serviceProviderRoleId: serviceProviderRoleId, success: { [weak self] () in
            self?.success(callback: success)}, failure: { [weak self] (message) in
                self?.failure(message: message, callback: failure)
            })
    }
    
    
    private func success(callback: () -> Void) {
        callback()
    }
    
    private func failure(message: String, callback: ((UpdateServiceProviderRoleError) -> Void)) {
        let wrongInput = "Wrong Value"
        if message == wrongInput {
            let error = UpdateServiceProviderRoleError(type: .wrongValue)
            callback(error)
        }
    }
}
