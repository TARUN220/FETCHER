//
//  AddServiceProviderDataManager.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 02/03/23.
//

import Foundation

public final class AddServiceProviderDataManager: AddServiceProviderDataContract {
    
    var database: AddServiceProviderDatabaseContract
    public init(database: AddServiceProviderDatabaseContract) {
        self.database = database
    }
    
    public func addServiceProvider(serviceProvider: ServiceProvider, success: @escaping () -> Void, failure: @escaping (AddServiceProviderError) -> Void) {
        database.addServiceProvider(serviceProvider: serviceProvider, success: { [weak self] () in
            self?.success(callback: success)
        }, failure: { [weak self] () in
            self?.failure(callback: failure)
        })
    }
    
    private func success(callback: () -> Void) {
        callback()
    }
    
    private func failure(callback: ((AddServiceProviderError) -> Void)) {
        let error = AddServiceProviderError(type: .irresponsiveDatabase)
        callback(error)
    }
}
