//
//  ServiceProviderDatabaseContract.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 02/03/23.
//

import Foundation

public protocol AddServiceProviderDatabaseContract {
    func addServiceProvider(serviceProvider: ServiceProvider, success: @escaping () -> Void, failure: @escaping () -> Void)
}

public protocol ServiceProviderListDatabaseContract {
    func getServiceProviderList(success: @escaping ([ServiceProvider]) -> Void, failure: @escaping () -> Void)
}

public protocol SearchServiceProviderDatabaseContract {
    func searchServiceProvider(columnName: String, columnValue: Any, success: @escaping ([ServiceProvider]) -> Void, failure: @escaping () -> Void)
}

public protocol DeleteServiceProviderDatabaseContract {
    func deleteServiceProvider(serviceProviderId: Int, success: @escaping ()-> Void, failure: @escaping (String) -> Void)
}

public protocol UpdateServiceProviderDatabaseContract {
    func updateServiceProvider(newValues: [String: Any], serviceProviderId: Int, success: @escaping () -> Void, failure: @escaping (String) -> Void)
}
