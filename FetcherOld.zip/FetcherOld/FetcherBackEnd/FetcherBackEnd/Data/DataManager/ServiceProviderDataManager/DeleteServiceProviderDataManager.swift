//
//  DeleteServiceProvider.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 13/03/23.
//

import Foundation

public final class DeleteServiceProviderDataManager: DeleteServiceProviderDataContract {
    
    var database: DeleteServiceProviderDatabaseContract
    
    public init(database: DeleteServiceProviderDatabaseContract) {
        self.database = database
    }
    
    public func deleteServiceProvider(serviceProviderId: Int, success: @escaping () -> Void, failure: @escaping (DeleteServiceProviderError) -> Void) {
        database.deleteServiceProvider(serviceProviderId: serviceProviderId, success: { [weak self] () in
            self?.success(callback: success)}, failure: { [weak self] (message) in
                self?.failure(message: message, callback: failure)
            })
    }
    
    
    private func success(callback: () -> Void) {
        callback()
    }
    
    private func failure(message: String, callback: ((DeleteServiceProviderError) -> Void)) {
        let wrongInput = "Wrong Value"
        if message == wrongInput {
            let error = DeleteServiceProviderError(type: .wrongValue)
            callback(error)
        }
    }
}
