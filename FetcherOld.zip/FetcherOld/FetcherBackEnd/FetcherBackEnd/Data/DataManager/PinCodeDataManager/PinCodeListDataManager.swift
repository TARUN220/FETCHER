//
//  PinListDataManager.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 07/03/23.
//

import Foundation

public final class PinCodeListDataManager: GetPinCodeListDataContract {
    
    var database: PinCodeListDatabaseContract
    public init(database: PinCodeListDatabaseContract) {
        self.database = database
    }
    
    public func getPinCodeList(success: @escaping ([PinCode]) -> Void, failure: @escaping (GetPinCodeListError) -> Void) {
        database.getPinCodeList(success: { [weak self] (pinCode) in
            self?.success(pinCode: pinCode, callback: success)
        }, failure: { [weak self] () in
            self?.failure(callback: failure)
        })
    }
    
    private func success(pinCode: [PinCode], callback: ([PinCode]) -> Void) {
        callback(pinCode)
    }
    
    private func failure(callback: ((GetPinCodeListError) -> Void)) {
        let error = GetPinCodeListError(type: .irresponsiveDatabase)
        callback(error)
    }
    
}
