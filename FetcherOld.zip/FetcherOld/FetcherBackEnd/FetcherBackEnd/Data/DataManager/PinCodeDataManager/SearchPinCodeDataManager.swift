//
//  SearchPinDataManager.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 07/03/23.
//

import Foundation
public class SearchPinCodeDataManager: SearchPinCodeDataContract {
    
    var database: SearchPinCodeDatabaseContract
    var columnName: String
    var columnValue: Any
    
    public init(database: SearchPinCodeDatabaseContract, columnName: String, columnValue: Any) {
        self.database = database
        self.columnName = columnName
        self.columnValue = columnValue
    }
    
    public func searchPinCode(success: @escaping ([PinCode]) -> Void, failure: @escaping (SearchPinCodeError) -> Void) {
        database.searchPinCode(columnName: columnName, columnValue: columnValue, success: { [weak self] (pinCode) in
            self?.success(pinCode: pinCode, callback: success)
        }, failure: { [weak self] () in
            self?.failure(callback: failure)
        })
    }
}

extension SearchPinCodeDataManager {
    private func success(pinCode: [PinCode], callback: (([PinCode]) -> Void)) {
        callback(pinCode)
    }
    
    private func failure(callback: ((SearchPinCodeError) -> Void)) {
        let error = SearchPinCodeError(type: .irresponsiveDatabase)
        callback(error)
    }
}
