//
//  PinDatabaseContract.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 07/03/23.
//

import Foundation

public protocol AddPinCodeDatabaseContract {
    func addPinCode(pinCode: PinCode, success: @escaping () -> Void, failure: @escaping () -> Void)
}

public protocol PinCodeListDatabaseContract {
    func getPinCodeList(success: @escaping ([PinCode]) -> Void, failure: @escaping () -> Void)
}

public protocol SearchPinCodeDatabaseContract {
    func searchPinCode(columnName: String, columnValue: Any, success: @escaping ([PinCode]) -> Void, failure: @escaping () -> Void)
}

public protocol UpdatePinCodeDatabaseContract {
    func updatePinCode(newValues: [String: Any], pinCodeId: Int, success: @escaping () -> Void, failure: @escaping (String) -> Void)
}
