//
//  AddPinDatabaseContract.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 07/03/23.
//

import Foundation

public final class AddPinCodeDataManager: AddPinCodeDataContract {
    
    var database: AddPinCodeDatabaseContract
    public init(database: AddPinCodeDatabaseContract) {
        self.database = database
    }
    
    public func addPinCode(pinCode: PinCode, success: @escaping () -> Void, failure: @escaping (AddPinCodeError) -> Void) {
        database.addPinCode(pinCode: pinCode, success: { [weak self] () in
            self?.success(callback: success)
        }, failure: { [weak self] () in
            self?.failure(callback: failure)
        })
    }
    
    private func success(callback: () -> Void) {
        callback()
    }
    
    private func failure(callback: ((AddPinCodeError) -> Void)) {
        let error = AddPinCodeError(type: .irresponsiveDatabase)
        callback(error)
    }
}
