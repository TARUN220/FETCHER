//
//  UpdatePinCodeDataManager.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 13/03/23.
//

import Foundation

public final class UpdatePinCodeDataManager: UpdatePinCodeDataContract {
    
    var database: UpdatePinCodeDatabaseContract
    
    public init(database: UpdatePinCodeDatabaseContract) {
        self.database = database
    }
    
    public func updatePinCode(newValues: [String: Any], pinCodeId: Int, success: @escaping () -> Void, failure: @escaping (UpdatePinCodeError) -> Void) {
        database.updatePinCode(newValues: newValues, pinCodeId: pinCodeId, success: { [weak self] () in
            self?.success(callback: success)}, failure: { [weak self] (message) in
                self?.failure(message: message, callback: failure)
            })
    }
    
    
    private func success(callback: () -> Void) {
        callback()
    }
    
    private func failure(message: String, callback: ((UpdatePinCodeError) -> Void)) {
        let wrongInput = "Wrong Value"
        if message == wrongInput {
            let error = UpdatePinCodeError(type: .wrongValue)
            callback(error)
        }
    }
}
