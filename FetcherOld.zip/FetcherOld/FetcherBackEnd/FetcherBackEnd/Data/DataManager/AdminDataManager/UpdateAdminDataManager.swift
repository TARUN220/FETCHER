//
//  UpdateAdminDataManager.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 14/03/23.
//

import Foundation

public final class UpdateAdminDataManager: UpdateAdminDataContract {
    
    var database: UpdateAdminDatabaseContract
    
    public init(database: UpdateAdminDatabaseContract) {
        self.database = database
    }
    
    public func updateAdmin(newValues: [String: Any], adminId: Int, success: @escaping () -> Void, failure: @escaping (UpdateAdminError) -> Void) {
        database.updateAdmin(newValues: newValues, adminId: adminId, success: { [weak self] () in
            self?.success(callback: success)}, failure: { [weak self] (message) in
                self?.failure(message: message, callback: failure)
            })
    }
    
    
    private func success(callback: () -> Void) {
        callback()
    }
    
    private func failure(message: String, callback: ((UpdateAdminError) -> Void)) {
        let wrongInput = "Wrong Value"
        if message == wrongInput {
            let error = UpdateAdminError(type: .wrongValue)
            callback(error)
        }
    }
}
