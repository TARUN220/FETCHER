//
//  AdminDatabaseContract.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 01/03/23.
//

import Foundation

public protocol SearchAdminDatabaseContract {
    func searchAdmin(columnName: String, columnValue: Any, success: @escaping ([Admin]) -> Void, failure: @escaping () -> Void)
}

public protocol UpdateAdminDatabaseContract {
    func updateAdmin(newValues: [String: Any], adminId: Int, success: @escaping () -> Void, failure: @escaping (String) -> Void)
}
