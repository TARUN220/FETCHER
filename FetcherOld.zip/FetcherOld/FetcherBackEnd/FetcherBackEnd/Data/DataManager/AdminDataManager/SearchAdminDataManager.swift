//
//  SearchAdminDataManager.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 01/03/23.
//

import Foundation

public class SearchAdminDataManager: SearchAdminDataContract {
    
    var database: SearchAdminDatabaseContract
    var columnName: String
    var columnValue: Any
    
    public init(database: SearchAdminDatabaseContract, columnName: String, columnValue: Any) {
        self.database = database
        self.columnName = columnName
        self.columnValue = columnValue
    }
    
    public func searchAdmin(success: @escaping ([Admin]) -> Void, failure: @escaping (SearchAdminError) -> Void) {
        database.searchAdmin(columnName: columnName, columnValue: columnValue, success: { [weak self] (admin) in
            self?.success(admin: admin, callback: success)
        }, failure: { [weak self] () in
            self?.failure(callback: failure)
        })
    }
}

extension SearchAdminDataManager {
    public func success(admin: [Admin], callback: ([Admin]) -> Void) {
        callback(admin)
    }
    
    private func failure(callback: ((SearchAdminError) -> Void)) {
        let error = SearchAdminError(type: .irresponsiveDatabase)
        callback(error)
    }
}
