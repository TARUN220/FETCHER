//
//  SearchServiceDataManager.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 09/03/23.
//

import Foundation

public class SearchServiceDataManager: SearchServiceDataContract {
    
    var database: SearchServiceDatabaseContract
    var columnName: String
    var columnValue: Any
    
    public init(database: SearchServiceDatabaseContract, columnName: String, columnValue: Any) {
        self.database = database
        self.columnName = columnName
        self.columnValue = columnValue
    }
    
    public func searchService(success: @escaping ([Service]) -> Void, failure: @escaping (SearchServiceError) -> Void) {
        database.searchService(columnName: columnName, columnValue: columnValue, success: { [weak self] (service) in
            self?.success(service: service, callback: success)
        }, failure: { [weak self] () in
            self?.failure(callback: failure)
        })
    }
}

extension SearchServiceDataManager {
    private func success(service: [Service], callback: (([Service]) -> Void)) {
        callback(service)
    }
    
    private func failure(callback: ((SearchServiceError) -> Void)) {
        let error = SearchServiceError(type: .irresponsiveDatabase)
        callback(error)
    }
}
