//
//  DeleteServiceDataManager.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 13/03/23.
//

import Foundation

public final class DeleteServiceDataManager: DeleteServiceDataContract {
    
    var database: DeleteServiceDatabaseContract
    
    public init(database: DeleteServiceDatabaseContract) {
        self.database = database
    }
    
    public func deleteService(columnName: String, columnValue: Any, success: @escaping () -> Void, failure: @escaping (DeleteServiceError) -> Void) {
        database.deleteService(columnName: columnName, columnValue: columnValue,  success: { [weak self] () in
            self?.success(callback: success)}, failure: { [weak self] (message) in
                self?.failure(message: message, callback: failure)
            })
    }
    
    
    private func success(callback: () -> Void) {
        callback()
    }
    
    private func failure(message: String, callback: ((DeleteServiceError) -> Void)) {
        let wrongInput = "Wrong Value"
        if message == wrongInput {
            let error = DeleteServiceError(type: .wrongValue)
            callback(error)
        }
    }
}
