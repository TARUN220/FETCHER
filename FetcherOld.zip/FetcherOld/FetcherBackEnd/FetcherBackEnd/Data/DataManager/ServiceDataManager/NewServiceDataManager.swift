//
//  NewServiceDataManager.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 08/03/23.
//

import Foundation

public final class NewServiceDataManager: NewServiceDataContract {
    
    var database: NewServiceDatabaseContract
    public init(database: NewServiceDatabaseContract) {
        self.database = database
    }
    
    public func newService(service: Service, success: @escaping () -> Void, failure: @escaping (NewServiceError) -> Void) {
        database.newService(service: service, success: { [weak self] () in
            self?.success(callback: success)
        }, failure: { [weak self] () in
            self?.failure(callback: failure)
        })
    }
    
    private func success(callback: () -> Void) {
        callback()
    }
    
    private func failure(callback: ((NewServiceError) -> Void)) {
        let error = NewServiceError(type: .irresponsiveDatabase)
        callback(error)
    }
}
