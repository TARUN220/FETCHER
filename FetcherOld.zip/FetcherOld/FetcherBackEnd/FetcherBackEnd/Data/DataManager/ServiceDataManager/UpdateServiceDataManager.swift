//
//  UpdateServiceDataManager.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 09/03/23.
//

import Foundation

public final class UpdateServiceDataManager: UpdateServiceDataContract {
    
    var database: UpdateServiceDatabaseContract
    
    public init(database: UpdateServiceDatabaseContract) {
        self.database = database
    }
    
    public func updateService(newValues: [String: Any], serviceId: Int, success: @escaping () -> Void, failure: @escaping (UpdateServiceError) -> Void) {
        database.updateService(newValues: newValues, serviceId: serviceId, success: { [weak self] () in
            self?.success(callback: success)}, failure: { [weak self] (message) in
                self?.failure(message: message, callback: failure)
            })
    }
    
    
    private func success(callback: () -> Void) {
        callback()
    }
    
    private func failure(message: String, callback: ((UpdateServiceError) -> Void)) {
        let wrongInput = "Wrong Value"
        if message == wrongInput {
            let error = UpdateServiceError(type: .wrongValue)
            callback(error)
        }
    }
}
