//
//  ServiceRequestListDataManager.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 08/03/23.
//

import Foundation

public final class ServiceRequestListDataManager: GetServiceRequestListDataContract {
    
    var database: ServiceRequestListDatabaseContract
    var columnName: String
    var columnValue: Any
    public init(database: ServiceRequestListDatabaseContract, columnName: String, columnValue: Any) {
        self.database = database
        self.columnName = columnName
        self.columnValue = columnValue
    }
    
    public func getServiceRequestList(success: @escaping ([Service]) -> Void, failure: @escaping (GetServiceRequestListError) -> Void) {
        database.getServiceRequestList(columnName: columnName, columnValue: columnValue, success: { [weak self] (service) in
            self?.success(service: service, callback: success)
        }, failure: { [weak self] () in
            self?.failure(callback: failure)
        })
    }
    
    private func success(service: [Service], callback: ([Service]) -> Void) {
        callback(service)
    }
    
    private func failure(callback: ((GetServiceRequestListError) -> Void)) {
        let error = GetServiceRequestListError(type: .irresponsiveDatabase)
        callback(error)
    }
    
}
