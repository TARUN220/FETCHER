//
//  ServiceDatabaseContract.swift
//  FetcherBackEnd
//
//  Created by tarun-pt6229 on 08/03/23.
//

import Foundation

public protocol NewServiceDatabaseContract {
    func newService(service: Service, success: @escaping () -> Void, failure: @escaping () -> Void)
}

public protocol ServiceListDatabaseContract {
    func getServiceList(success: @escaping ([Service]) -> Void, failure: @escaping () -> Void)
}

public protocol SearchServiceDatabaseContract {
    func searchService(columnName: String, columnValue: Any, success: @escaping ([Service]) -> Void, failure: @escaping () -> Void)
}

public protocol ServiceRequestListDatabaseContract {
    func getServiceRequestList(columnName: String, columnValue: Any, success: @escaping ([Service]) -> Void, failure: @escaping () -> Void)
}

public protocol UpdateServiceDatabaseContract {
    func updateService(newValues: [String: Any], serviceId: Int, success: @escaping () -> Void, failure: @escaping (String) -> Void)
}

public protocol DeleteServiceDatabaseContract {
    func deleteService(columnName: String, columnValue:
                       Any, success: @escaping ()-> Void, failure: @escaping (String) -> Void)
}
