//
//  PinCodeListView.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 07/03/23.
//

import Foundation
import AppKit
import FetcherBackEnd

class PinCodeListView: NSView {
    var presenter : PinCodeListPresenterContract
//    var pinCode: [PinCode]
    
    init(presenter: PinCodeListPresenterContract) {
//        self.pinCode = pinCode
        self.presenter = presenter
        super.init(frame: NSZeroRect)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidMoveToSuperview() {
        if superview != nil {
            presenter.viewLoaded()
        }
    }
}

extension PinCodeListView: PinCodeListViewContract {
    func load(pinCodeList: [FetcherBackEnd.PinCode]) {
        print("PIN CODE List..")
        for (i,pinCode) in pinCodeList.enumerated() {
            print("\(i+1). \(pinCode.pinCode)")
        }
    }
    
    func failure(error: FetcherBackEnd.GetPinCodeListError) {
        print("An error occured.. \(error)")
    }
}
