//
//  SearchPinCodeView.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 07/03/23.
//

import Foundation
import AppKit
import FetcherBackEnd

class SearchPinCodeView: NSView {
    var presenter: SearchPinCodePresenterContract
    var columnName: String
    var columnValue: Any
    
    init(columnName: String, columnValue: Any, presenter: SearchPinCodePresenterContract) {
        self.presenter = presenter
        self.columnName = columnName
        self.columnValue = columnValue
        super.init(frame: NSZeroRect)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidMoveToSuperview() {
        if superview != nil {
            presenter.viewLoaded(columnName: columnName, columnValue: columnValue)
        }
    }
}

extension SearchPinCodeView: SearchPinCodeViewContract {
    func load(pinCode: [PinCode], flag: inout Bool, id: inout Int) {
        print("\tPIN CODE DETAILS: ")
        print(pinCode.count)
        for pinCodeDetail in pinCode {
            print("Id: \(String(describing: pinCodeDetail.id)), PIN CODE: \(pinCodeDetail.pinCode)")
            id = pinCodeDetail.id
            flag = true
        }
        sleep(2)
//        print("\tThe emailId already exists..")
        return
    }
    
    func failure(error: FetcherBackEnd.SearchPinCodeError) {
        print("\tNO PinCode aVAILABLE.. for the given mailID..😅 ")
        sleep(2)
    }
    
}
