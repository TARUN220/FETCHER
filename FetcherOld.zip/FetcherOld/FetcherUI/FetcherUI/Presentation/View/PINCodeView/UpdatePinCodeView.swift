//
//  UpdatePinCodeView.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 13/03/23.
//

import Foundation
import AppKit
import FetcherBackEnd

class UpdatePinCodeView: NSView {
    
    var presenter: UpdatePinCodePresenterContract
    
    var newValues: [String: Any]
    var pinCodeId: Int
    
    init(newValues: [String: Any], pinCodeId: Int, presenter: UpdatePinCodePresenterContract) {
        
        self.presenter = presenter
        self.newValues = newValues
        self.pinCodeId = pinCodeId
        super.init(frame: NSZeroRect)
        
    }
    
    required init?(coder decoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidMoveToSuperview() {
        if superview != nil {
            presenter.viewLoaded(newValues: newValues, pinCodeId: pinCodeId)
        }
    }
    
}

extension UpdatePinCodeView: UpdatePinCodeViewContract {
    
    func load() {
        print("PinCode Updated Successfuly")
    }
}
