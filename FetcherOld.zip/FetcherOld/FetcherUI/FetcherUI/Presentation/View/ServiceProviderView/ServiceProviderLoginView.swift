//
//  ServiceProviderLoginView.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 03/03/23.
//

import Foundation
import AppKit
import FetcherBackEnd

class ServiceProviderLoginView: NSView {
    var columnName: String
    var columnValue: Any
    var presenter: ServiceProviderLoginPresenterContract
    init(columnName: String, columnValue: Any, presenter: ServiceProviderLoginPresenterContract) {
        self.columnName = columnName
        self.columnValue = columnValue
        self.presenter = presenter
        super.init(frame: NSZeroRect)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidMoveToSuperview() {
        if superview != nil {
            presenter.viewLoaded(columnName: columnName, columnValue: columnValue)
        }
    }
}

extension ServiceProviderLoginView: ServiceProviderLoginViewContract {
    func loginSuccess() {
        print("\tSuccessfully LOGGED IN..")
    }
    
    func invalidEmailId() {
        print("\tINVALID EMAIL ID..")
    }
    
    func invalidPassword() {
        print("\tINVLAID PASSWORD..")
    }
    
    func invalidRole() {
        print("\tInvalid SP Role..")
    }
    
    func dataBaseFailure() {
        print("\tDATABASE FAILURE..")
    }
}
