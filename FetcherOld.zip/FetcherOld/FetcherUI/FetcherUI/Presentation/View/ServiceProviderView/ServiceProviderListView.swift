//
//  ServiceProviderListView.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 08/03/23.
//

import Foundation
import AppKit
import FetcherBackEnd

class ServiceProviderListView: NSView {
    var presenter : ServiceProviderListPresenterContract
//    var serviceProvider: [ServiceProvider]
    
    init(presenter: ServiceProviderListPresenterContract) {
//        self.serviceProvider = serviceProvider
        self.presenter = presenter
        super.init(frame: NSZeroRect)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidMoveToSuperview() {
        if superview != nil {
            presenter.viewLoaded()
        }
    }
}

extension ServiceProviderListView: ServiceProviderListViewContract {
    func load(serviceProviderList: [FetcherBackEnd.ServiceProvider]) {
        print("Service Provider List..")
        for (i,serviceProvider) in serviceProviderList.enumerated() {
            print("\(i+1). Name: \(serviceProvider.name)\tRole: \(serviceProvider.role.role)\tPIN CODE: \(serviceProvider.pinCode!.pinCode)\tExp: \(serviceProvider.experience)")
        }
    }
    
    func failure(error: FetcherBackEnd.GetServiceProviderListError) {
        print("An error occured.. \(error)")
    }
}
