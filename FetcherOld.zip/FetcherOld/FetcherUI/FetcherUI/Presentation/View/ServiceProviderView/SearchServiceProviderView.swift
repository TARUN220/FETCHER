//
//  SearchServiceProviderView.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 03/03/23.
//

import Foundation
import AppKit
import FetcherBackEnd

class SearchServiceProviderView: NSView {
    var presenter: SearchServiceProviderPresenterContract
    var columnName: String
    var columnValue: Any
    
    init(columnName: String, columnValue: Any, presenter: SearchServiceProviderPresenterContract) {
        self.presenter = presenter
        self.columnName = columnName
        self.columnValue = columnValue
        super.init(frame: NSZeroRect)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidMoveToSuperview() {
        if superview != nil {
            presenter.viewLoaded(columnName: columnName, columnValue: columnValue)
        }
    }
}

extension SearchServiceProviderView: SearchServiceProviderViewContract {
    func load(serviceProvider: [ServiceProvider], flag: inout Bool) {
        print("\tServiceProvider DETAILS: ")
        print(serviceProvider.count)
        for (i,serviceProviderDetail) in serviceProvider.enumerated() {
            print("\(i+1): Id: \(String(describing: serviceProviderDetail.id)), Name: \(serviceProviderDetail.name), EmailId: \(serviceProviderDetail.emailId), Role: \(serviceProviderDetail.role.role): \(String(describing: serviceProviderDetail.mobileNumber!)), PIN CODE: \(String(describing: serviceProviderDetail.pinCode!.pinCode)), Experience: \(serviceProviderDetail.experience)")
            flag = true
        }
        sleep(2)
        print("\tThe emailId already exists..")
        return
    }
    
    func failure(error: FetcherBackEnd.SearchServiceProviderError) {
        print("\tNO ServiceProvider aVAILABLE.. for the given mailID..😅 ")
        sleep(2)
    }
    
}
