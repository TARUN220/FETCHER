//
//  DeleteServiceProviderView.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 13/03/23.
//

import Foundation
import AppKit
import FetcherBackEnd

class DeleteServiceProviderView: NSView {
    
    var presenter: DeleteServiceProviderPresenterContract
    var serviceProviderId: Int
    
    init(serviceProviderId: Int, presenter: DeleteServiceProviderPresenterContract) {
        
        self.presenter = presenter
        self.serviceProviderId = serviceProviderId
        super.init(frame: NSZeroRect)
        
    }
    
    required init?(coder decoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidMoveToSuperview() {
        if superview != nil {
            presenter.viewLoaded(serviceProviderId: serviceProviderId)
        }
    }
    
}

extension DeleteServiceProviderView: DeleteServiceProviderViewContract {
    
    func load() {
        print("ServiceProvider Deleted Successfuly")
    }
    func failure(error: DeleteServiceProviderError) {
        print("Error: ", error)
    }
}
