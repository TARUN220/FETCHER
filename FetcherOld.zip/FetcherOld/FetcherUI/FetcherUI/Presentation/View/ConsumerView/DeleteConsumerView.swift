//
//  DeleteConsumerView.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 13/03/23.
//

import Foundation
import AppKit
import FetcherBackEnd

class DeleteConsumerView: NSView {
    
    var presenter: DeleteConsumerPresenterContract
    var consumerId: Int
    
    init(consumerId: Int, presenter: DeleteConsumerPresenterContract) {
        
        self.presenter = presenter
        self.consumerId = consumerId
        super.init(frame: NSZeroRect)
        
    }
    
    required init?(coder decoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidMoveToSuperview() {
        if superview != nil {
            presenter.viewLoaded(consumerId: consumerId)
        }
    }
    
}

extension DeleteConsumerView: DeleteConsumerViewContract {
    
    func load() {
        print("Consumer Deleted Successfuly")
    }
    func failure(error: DeleteConsumerError) {
        print("Error: ", error)
    }
}
