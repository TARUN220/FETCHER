//
//  ConsumerLoginView.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 28/02/23.
//

import Foundation
import AppKit
import FetcherBackEnd

class ConsumerLoginView: NSView {
    var columnName: String
    var columnValue: Any
    var presenter: ConsumerLoginPresenterContract
    init(columnName: String, columnValue: Any, presenter: ConsumerLoginPresenterContract) {
        self.columnName = columnName
        self.columnValue = columnValue
        self.presenter = presenter
        super.init(frame: NSZeroRect)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidMoveToSuperview() {
        if superview != nil {
            presenter.viewLoaded(columnName: columnName, columnValue: columnValue)
        }
    }
}

extension ConsumerLoginView: ConsumerLoginViewContract {
    func loginSuccess() {
        print("\tSuccessfully LOGGED IN..")
    }
    
    func invalidEmailId() {
        print("\tINVALID EMAIL ID..")
    }
    
    func invalidPassword() {
        print("\tINVLAID PASSWORD..")
    }
    
    func dataBaseFailure() {
        print("\tDATABASE FAILURE..")
    }
}
