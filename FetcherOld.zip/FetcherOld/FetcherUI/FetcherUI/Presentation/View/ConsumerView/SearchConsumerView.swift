//
//  SearchConsumerView.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 24/02/23.
//

import Foundation
import AppKit
import FetcherBackEnd

class SearchConsumerView: NSView {
    var presenter: SearchConsumerPresenterContract
    var columnName: String
    var columnValue: Any
    
    init(columnName: String, columnValue: Any, presenter: SearchConsumerPresenterContract) {
        self.presenter = presenter
        self.columnName = columnName
        self.columnValue = columnValue
        super.init(frame: NSZeroRect)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidMoveToSuperview() {
        if superview != nil {
            presenter.viewLoaded(columnName: columnName, columnValue: columnValue)
        }
    }
}

extension SearchConsumerView: SearchConsumerViewContract {
    func load(consumer: [Consumer], flag: inout Bool) {
        print("\tCONSUMER DETAILS: ")
        for consumerDetail in consumer {
            print("Id: \(String(describing: consumerDetail.id)), Name: \(consumerDetail.name), EmailId: \(consumerDetail.emailId), Password: \(consumerDetail.password): \(String(describing: consumerDetail.mobileNumber)), Location: \(String(describing: consumerDetail.pinCode?.pinCode))")
            flag = true
        }
        sleep(2)
        print("\tThe emailId already exists..")
        return
    }
    
    func failure(error: FetcherBackEnd.SearchConsumerError) {
        print("\tNO CONSUmer aVAILABLE.. for the given mailID..😅 ")
        sleep(2)
    }
    
}
