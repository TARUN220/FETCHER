//
//  DeleteServiceView.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 13/03/23.
//

import Foundation
import AppKit
import FetcherBackEnd

class DeleteServiceView: NSView {
    
    var presenter: DeleteServicePresenterContract
    var columnName: String
    var columnValue: Any
    
    init(columnName: String, columnValue: Any, presenter: DeleteServicePresenterContract) {
        
        self.presenter = presenter
        self.columnName = columnName
        self.columnValue = columnValue
        super.init(frame: NSZeroRect)
        
    }
    
    required init?(coder decoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidMoveToSuperview() {
        if superview != nil {
            presenter.viewLoaded(columnName: columnName, columnValue: columnValue)
        }
    }
    
}

extension DeleteServiceView: DeleteServiceViewContract {
    
    func load() {
        print("Service Deleted Successfuly")
    }
    func failure(error: DeleteServiceError) {
        print("Error: ", error)
    }
}
