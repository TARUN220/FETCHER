//
//  SearchServiceView.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 09/03/23.
//

import Foundation
import AppKit
import FetcherBackEnd

class SearchServiceView: NSView {
    var presenter: SearchServicePresenterContract
    var columnName: String
    var columnValue: Any
    
    init(columnName: String, columnValue: Any, presenter: SearchServicePresenterContract) {
        self.presenter = presenter
        self.columnName = columnName
        self.columnValue = columnValue
        super.init(frame: NSZeroRect)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidMoveToSuperview() {
        if superview != nil {
            presenter.viewLoaded(columnName: columnName, columnValue: columnValue)
        }
    }
}

extension SearchServiceView: SearchServiceViewContract {
    func load(service: [Service], flag: inout Bool, id: inout Int) {
        print("\tService DETAILS: ")
        print(service.count)
        for (i, service) in service.enumerated() {
            print("\(i+1): serviceId: \(service.id), serviceDateAndTime: \(service.dateAndTime), Requested Consumer: \(service.consumer.name), Service Provider: \(service.serviceProvider.name), Role Needed: \(service.serviceProvider.role.role), Service Description: \(service.description), Service Amount: \(String(describing: service.amount!)), Appx TimeInMins: \(String(describing: service.approximateTimeInMinutes!))")
            id = service.id
            flag = true
        }
        sleep(2)
//        print("\tThe emailId already exists..")
        return
    }
    
    func failure(error: FetcherBackEnd.SearchServiceError) {
        print("\tNO Service aVAILABLE.. for the given mailID..😅 ")
        sleep(2)
    }
    
}
