//
//  ServiceRequestListView.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 08/03/23.
//

import Foundation
import AppKit
import FetcherBackEnd

class ServiceRequestListView: NSView {
    var presenter : ServiceRequestListPresenterContract
//    var serviceRequest: [ServiceRequest]
    var columnName: String
    var columnValue: Any
    
    init(presenter: ServiceRequestListPresenterContract, columnName: String, columnValue: Any) {
        self.presenter = presenter
        self.columnName = columnName
        self.columnValue = columnValue
        super.init(frame: NSZeroRect)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidMoveToSuperview() {
        if superview != nil {
            presenter.viewLoaded(columnName: columnName, columnValue: columnValue)
        }
    }
}

extension ServiceRequestListView: ServiceRequestListViewContract {
    func load(serviceRequestList: [FetcherBackEnd.Service]) {
        print("Service List.. ✌️")
        for (i, service) in serviceRequestList.enumerated() {
            print("\(i+1): serviceId: \(service.id), serviceDateAndTime: \(service.dateAndTime), Requested Consumer: \(service.consumer.name), Service Provider: \(service.serviceProvider.name), Role Needed: \(service.serviceProvider.role.role), Service Description: \(service.description)")
        }
    }
    
    func failure(error: FetcherBackEnd.GetServiceRequestListError) {
        print("An error occured.. \(error)\n There are no requested services..")
    }
}
