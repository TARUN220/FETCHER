//
//  UpdateServiceView.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 09/03/23.
//

import Foundation
import AppKit
import FetcherBackEnd

class UpdateServiceView: NSView {
    
    var presenter: UpdateServicePresenterContract
    
    var newValues: [String: Any]
    var serviceId: Int
    
    init(newValues: [String: Any], serviceId: Int, presenter: UpdateServicePresenterContract) {
        
        self.presenter = presenter
        self.newValues = newValues
        self.serviceId = serviceId
        super.init(frame: NSZeroRect)
        
    }
    
    required init?(coder decoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidMoveToSuperview() {
        if superview != nil {
            presenter.viewLoaded(newValues: newValues, serviceId: serviceId)
        }
    }
    
}

extension UpdateServiceView: UpdateServiceViewContract {
    
    func load() {
        print("Service Updated Successfuly")
    }
}
