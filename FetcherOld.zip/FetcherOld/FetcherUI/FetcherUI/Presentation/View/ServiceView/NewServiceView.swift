//
//  NewServiceView.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 08/03/23.
//

import Foundation
import AppKit
import FetcherBackEnd

class NewServiceView: NSView {
    var presenter : NewServicePresenterContract
    var service: Service
    
    init(service: Service, presenter: NewServicePresenterContract) {
        self.service = service
        self.presenter = presenter
        super.init(frame: NSZeroRect)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidMoveToSuperview() {
        if superview != nil {
            presenter.viewLoaded(service: service)
        }
    }
}

extension NewServiceView: NewServiceViewContract {
    func serviceRequested() {
        print("UR Service was rejected..")
    }
    
    func serviceBooked() {
        print("UR Service was booked")
    }
    
    func serviceRejected() {
        print("UR service was rejected..")
    }
    
    func serviceSuccess() {
        print("SUCCESS DONE..")
    }
}
