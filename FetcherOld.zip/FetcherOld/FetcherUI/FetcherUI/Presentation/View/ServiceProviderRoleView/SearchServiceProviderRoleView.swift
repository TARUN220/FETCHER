//
//  SearchServiceProviderRoleView.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 02/03/23.
//

import Foundation
import AppKit
import FetcherBackEnd

class SearchServiceProviderRoleView: NSView {
    var presenter: SearchServiceProviderRolePresenterContract
    var columnName: String
    var columnValue: Any
    
    init(columnName: String, columnValue: Any, presenter: SearchServiceProviderRolePresenterContract) {
        self.presenter = presenter
        self.columnName = columnName
        self.columnValue = columnValue
        super.init(frame: NSZeroRect)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidMoveToSuperview() {
        if superview != nil {
            presenter.viewLoaded(columnName: columnName, columnValue: columnValue)
        }
    }
}

extension SearchServiceProviderRoleView: SearchServiceProviderRoleViewContract {
    func load(serviceProviderRole: [ServiceProviderRole], flag: inout Bool, id: inout Int) {
        print("\tServiceProviderR0le DETAILS: ")
        for serviceProviderRoleDetail in serviceProviderRole {
            print("Id: \(String(describing: serviceProviderRoleDetail.id)), ROLE: \(serviceProviderRoleDetail.role)")
            id = serviceProviderRoleDetail.id
            flag = true
        }
        sleep(2)
//        print("\tThe emailId already exists..")
        return
    }
    
    func failure(error: FetcherBackEnd.SearchServiceProviderRoleError) {
        print("\tNO ServiceProviderRole aVAILABLE.. for the given mailID..😅 ")
        sleep(2)
    }
    
}
