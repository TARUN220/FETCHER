//
//  UpdateServiceProviderRoleView.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 10/03/23.
//

import Foundation
import AppKit
import FetcherBackEnd

class UpdateServiceProviderRoleView: NSView {
    
    var presenter: UpdateServiceProviderRolePresenterContract
    
    var newValues: [String: Any]
    var serviceProviderRoleId: Int
    
    init(newValues: [String: Any], serviceProviderRoleId: Int, presenter: UpdateServiceProviderRolePresenterContract) {
        
        self.presenter = presenter
        self.newValues = newValues
        self.serviceProviderRoleId = serviceProviderRoleId
        super.init(frame: NSZeroRect)
        
    }
    
    required init?(coder decoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidMoveToSuperview() {
        if superview != nil {
            presenter.viewLoaded(newValues: newValues, serviceProviderRoleId: serviceProviderRoleId)
        }
    }
    
}

extension UpdateServiceProviderRoleView: UpdateServiceProviderRoleViewContract {
    
    func load() {
        print("ServiceProviderRole Updated Successfuly")
    }
}
