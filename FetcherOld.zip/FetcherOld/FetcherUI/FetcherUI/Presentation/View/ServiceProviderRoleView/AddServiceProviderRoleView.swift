//
//  AddServiceProviderRoleView.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 02/03/23.
//

import Foundation
import AppKit
import FetcherBackEnd

class AddServiceProviderRoleView: NSView {
    var presenter : AddServiceProviderRolePresenterContract
    var serviceProviderRole: ServiceProviderRole
    
    init(serviceProviderRole: ServiceProviderRole, presenter: AddServiceProviderRolePresenterContract) {
        self.serviceProviderRole = serviceProviderRole
        self.presenter = presenter
        super.init(frame: NSZeroRect)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidMoveToSuperview() {
        if superview != nil {
            presenter.viewLoaded(serviceProviderRole: serviceProviderRole)
        }
    }
}

extension AddServiceProviderRoleView: AddServiceProviderRoleViewContract {
    func failure() {
        print("Not able to add New SP Role!..🔴")
        print("Please try some other time..\n")
    }
    
    func load() {
        print("Successfully added the new SP Role .. 😇")
        print("Try to use the role for SP ..🦾\n")
    }
}
