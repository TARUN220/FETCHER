//
//  UpdateAdminView.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 14/03/23.
//

import Foundation
import AppKit
import FetcherBackEnd

class UpdateAdminView: NSView {
    
    var presenter: UpdateAdminPresenterContract
    
    var newValues: [String: Any]
    var adminId: Int
    
    init(newValues: [String: Any], adminId: Int, presenter: UpdateAdminPresenterContract) {
        
        self.presenter = presenter
        self.newValues = newValues
        self.adminId = adminId
        super.init(frame: NSZeroRect)
        
    }
    
    required init?(coder decoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidMoveToSuperview() {
        if superview != nil {
            presenter.viewLoaded(newValues: newValues, adminId: adminId)
        }
    }
    
}

extension UpdateAdminView: UpdateAdminViewContract {
    
    func load() {
        print("Admin Updated Successfuly")
    }
}
