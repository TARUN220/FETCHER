//
//  AdminLoginView.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 01/03/23.
//

import Foundation
import AppKit
import FetcherBackEnd

class AdminLoginView: NSView {
    var columnName: String
    var columnValue: Any
    var presenter: AdminLoginPresenterContract
    init(columnName: String, columnValue: Any, presenter: AdminLoginPresenterContract) {
        self.columnName = columnName
        self.columnValue = columnValue
        self.presenter = presenter
        super.init(frame: NSZeroRect)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidMoveToSuperview() {
        if superview != nil {
            presenter.viewLoaded(columnName: columnName, columnValue: columnValue)
        }
    }
}

extension AdminLoginView: AdminLoginViewContract {
    func loginSuccess() {
        print("\tADMIN Successfully LOGGED IN..")
    }
    
    func invalidEmailId() {
        print("\tINVALID EMAIL ID..")
    }
    
    func invalidPassword() {
        print("\tINVLAID PASSWORD..")
    }
    
    func dataBaseFailure() {
        print("\tDATABASE FAILURE..")
    }
}
