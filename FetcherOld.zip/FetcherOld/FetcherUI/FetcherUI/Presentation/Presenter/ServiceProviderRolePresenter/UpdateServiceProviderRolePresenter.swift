//
//  UpdateServiceProviderRolePresenter.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 10/03/23.
//

import Foundation
import FetcherBackEnd

class UpdateServiceProviderRolePresenter {
    
    weak var view: UpdateServiceProviderRoleViewContract?
    var updateServiceProviderRole: UpdateServiceProviderRole
    weak var router: UpdateServiceProviderRoleRouterContract?
    
    init(updateServiceProviderRole: UpdateServiceProviderRole) {
        self.updateServiceProviderRole = updateServiceProviderRole
    }
}

extension UpdateServiceProviderRolePresenter: UpdateServiceProviderRolePresenterContract {
    
    func viewLoaded(newValues: [String: Any], serviceProviderRoleId: Int) {
        let request = UpdateServiceProviderRoleRequest(newValues: newValues, serviceProviderRoleId: serviceProviderRoleId)
        updateServiceProviderRole.execute(request: request, onSuccess: { [weak self] (response) in
            self?.result()
        }, onFailure: { [weak self] (error) in
            self?.failed(error: error)
        })
        
        while updateServiceProviderRole.response == nil && updateServiceProviderRole.error == nil {
            
        }
        if let response = updateServiceProviderRole.response {
            view?.load()
        }
        else if let error = updateServiceProviderRole.error {
//            view?.failure()
            print("Error")
        }
    }
}

extension UpdateServiceProviderRolePresenter {
    
    func result() {
        view?.load()
    }
    
    func failed(error: UpdateServiceProviderRoleError) {
        
    }
}

