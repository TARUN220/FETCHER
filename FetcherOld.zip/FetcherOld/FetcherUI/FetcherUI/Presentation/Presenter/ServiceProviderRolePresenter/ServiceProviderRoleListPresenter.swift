//
//  ServiceProviderRoleListPresenter.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 02/03/23.
//

import Foundation
import FetcherBackEnd

class ServiceProviderRoleListPresenter {
    weak var view: ServiceProviderRoleListViewContract?
    weak var router: ServiceProviderRoleListRouterContract?
    var serviceProviderRoleList: GetServiceProviderRoleList
    
    init(serviceProviderRoleList: GetServiceProviderRoleList) {
        self.serviceProviderRoleList = serviceProviderRoleList
    }
}

extension ServiceProviderRoleListPresenter: ServiceProviderRoleListPresenterContract {
    func viewLoaded() {
        let request = GetServiceProviderRoleListRequest()
        serviceProviderRoleList.execute(request: request, onSuccess: { [weak self] (response) in
            self?.result(serviceProviderRoleList: response.serviceProviderRole)
        }, onFailure: { [weak self] (error) in
            self?.failed(error: error)
        })
        
        while serviceProviderRoleList.response == nil && serviceProviderRoleList.error == nil {
            
        }
        if let response = serviceProviderRoleList.response {
            view?.load(serviceProviderRoleList: response.serviceProviderRole)
        }
        else if let error = serviceProviderRoleList.error {
            view?.failure(error: error)
        }
    }
}

extension ServiceProviderRoleListPresenter {
    func result(serviceProviderRoleList: [ServiceProviderRole]) {
        view?.load(serviceProviderRoleList: serviceProviderRoleList)
    }
    
    func failed(error: GetServiceProviderRoleListError) {
        view?.failure(error: error)
    }
}
