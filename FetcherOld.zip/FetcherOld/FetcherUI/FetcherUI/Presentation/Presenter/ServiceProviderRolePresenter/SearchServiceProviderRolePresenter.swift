//
//  SearchServiceProviderRolePresenter.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 02/03/23.
//

import Foundation
import FetcherBackEnd

class SearchServiceProviderRolePresenter {
    weak var view: SearchServiceProviderRoleViewContract?
    var searchServiceProviderRole: SearchServiceProviderRole
    weak var router: SearchServiceProviderRoleRouterContract?
    var serviceProviderRole: ServiceProviderRole?
    var flag = false
    var id = 0
    init(searchServiceProviderRole: SearchServiceProviderRole) {
        self.searchServiceProviderRole = searchServiceProviderRole
    }
}

extension SearchServiceProviderRolePresenter: SearchServiceProviderRolePresenterContract {
    func viewLoaded(columnName: String, columnValue: Any) {
        let request = SearchServiceProviderRoleRequest(columnName: columnName, columnType: columnValue)
        searchServiceProviderRole.execute(request: request, onSuccess: { [weak self] (response) in
            self?.result(serviceProviderRole: response.serviceProviderRole)
        }, onFailure: { [weak self] (error) in
            self?.failure(error: error)
        })
        while searchServiceProviderRole.searchServiceProviderRoleResponse == nil && searchServiceProviderRole.searchServiceProviderRoleError == nil {
            sleep(1)
        }
        if let error = searchServiceProviderRole.searchServiceProviderRoleError {
            view?.failure(error: error)
        }
        if let serviceProviderRole = searchServiceProviderRole.searchServiceProviderRoleResponse?.serviceProviderRole {
            view?.load(serviceProviderRole: serviceProviderRole, flag: &flag, id: &id)
        }
    }
    }

extension SearchServiceProviderRolePresenter {
    func result(serviceProviderRole: [ServiceProviderRole]) {
        view?.load(serviceProviderRole: serviceProviderRole, flag: &flag, id: &id)
    }
    
    func failure(error: SearchServiceProviderRoleError) {
        view?.failure(error: error)
    }
}
