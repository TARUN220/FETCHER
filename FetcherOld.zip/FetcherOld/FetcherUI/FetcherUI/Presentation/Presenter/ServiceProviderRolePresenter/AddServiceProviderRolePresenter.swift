//
//  AddServiceProviderRolePresenter.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 02/03/23.
//

import Foundation
import FetcherBackEnd

class AddServiceProviderRolePresenter {
    weak var view: AddServiceProviderRoleViewContract?
    weak var router: AddServiceProviderRoleRouterContract?
    var addServiceProviderRole: AddServiceProviderRole
    
    init(addServiceProviderRole: AddServiceProviderRole) {
        self.addServiceProviderRole = addServiceProviderRole
    }
}

extension AddServiceProviderRolePresenter: AddServiceProviderRolePresenterContract {
    func viewLoaded(serviceProviderRole: FetcherBackEnd.ServiceProviderRole) {
        let request = AddServiceProviderRoleRequest(serviceProviderRole: serviceProviderRole)
        addServiceProviderRole.execute(request: request, onSuccess: { [weak self] (response) in
            self?.result()
        }, onFailure: { [weak self] (error) in
            self?.failed()
        })
        
        while addServiceProviderRole.response == nil {
            
        }
    //        //sleep(5)
    //
        if addServiceProviderRole.response != nil {
            print("%%")
            view?.load()
        }
        else {
            view?.failure()
        }
    }
}

extension AddServiceProviderRolePresenter {
    func result() {
        view?.load()
    }
    
    func failed() {
        view?.failure()
    }
}
