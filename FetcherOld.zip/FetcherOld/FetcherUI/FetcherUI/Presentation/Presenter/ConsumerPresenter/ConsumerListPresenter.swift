//
//  ConsumerListPresenter.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 13/03/23.
//

import Foundation
import FetcherBackEnd

class ConsumerListPresenter {
    weak var view: ConsumerListViewContract?
    weak var router: ConsumerListRouterContract?
    var consumerList: GetConsumerList
    
    init(consumerList: GetConsumerList) {
        self.consumerList = consumerList
    }
}

extension ConsumerListPresenter: ConsumerListPresenterContract {
    func viewLoaded() {
        let request = GetConsumerListRequest()
        consumerList.execute(request: request, onSuccess: { [weak self] (response) in
            self?.result(consumerList: response.consumer)
        }, onFailure: { [weak self] (error) in
            self?.failed(error: error)
        })
        
        while consumerList.response == nil && consumerList.error == nil {
            
        }
        if let response = consumerList.response {
            view?.load(consumerList: response.consumer)
        }
        else if let error = consumerList.error {
            view?.failure(error: error)
        }
    }
}

extension ConsumerListPresenter {
    func result(consumerList: [Consumer]) {
        view?.load(consumerList: consumerList)
    }
    
    func failed(error: GetConsumerListError) {
        view?.failure(error: error)
    }
}
