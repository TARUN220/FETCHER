//
//  SearchConsumerPresenter.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 24/02/23.
//

import Foundation
import FetcherBackEnd

class SearchConsumerPresenter {
    weak var view: SearchConsumerViewContract?
    var searchConsumer: SearchConsumer
    weak var router: SearchConsumerRouterContract?
    var consumer: Consumer?
    var flag = false
    init(searchConsumer: SearchConsumer) {
        self.searchConsumer = searchConsumer
    }
}

extension SearchConsumerPresenter: SearchConsumerPresenterContract {
    func viewLoaded(columnName: String, columnValue: Any) {
        let request = SearchConsumerRequest(columnName: columnName, columnType: columnValue)
        searchConsumer.execute(request: request, onSuccess: { [weak self] (response) in
            self?.result(consumer: response.consumer)
        }, onFailure: { [weak self] (error) in
            self?.failure(error: error)
        })
        while searchConsumer.searchConsumerResponse == nil && searchConsumer.searchConsumerError == nil {
            sleep(1)
        }
        if let error = searchConsumer.searchConsumerError {
            view?.failure(error: error)
        }
        if let consumer = searchConsumer.searchConsumerResponse?.consumer {
            view?.load(consumer: consumer, flag: &flag)
        }
    }
    }

extension SearchConsumerPresenter {
    func result(consumer: [Consumer]) {
        view?.load(consumer: consumer, flag: &flag)
    }
    
    func failure(error: SearchConsumerError) {
        view?.failure(error: error)
    }
}
