//
//  AddConsumerPresentefr.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 22/02/23.
//

import Foundation
import FetcherBackEnd

class AddConsumerPresenter {
    weak var view: AddConsumerViewContract?
    var addConsumer: AddConsumer
    weak var router: AddConsumerRouterContract?
    
    init(addConsumer: AddConsumer) {
        self.addConsumer = addConsumer
    }
}

extension AddConsumerPresenter: AddConsumerPresenterContract {
    func viewLoaded(consumer: FetcherBackEnd.Consumer) {
        let request = AddConsumerRequest(consumer: consumer)
        addConsumer.execute(request: request, onSuccess: {
            [weak self] (response) in
            self?.result()
        }, onFailure: { [weak self] (error) in
            self?.failed()
        })
        while addConsumer.response == nil && addConsumer.error == nil {

        }
//        //sleep(5)
//
        if addConsumer.response != nil {
            view?.load()
        }
        else {
            view?.failure()
        }
    }
}

extension AddConsumerPresenter {
    func result() {
        view?.load()
    }
    
    func failed() {
        view?.failure()
    }
}
