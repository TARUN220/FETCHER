//
//  ServiceProviderListPresenter.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 08/03/23.
//

import Foundation
import FetcherBackEnd

class ServiceProviderListPresenter {
    weak var view: ServiceProviderListViewContract?
    weak var router: ServiceProviderListRouterContract?
    var serviceProviderList: GetServiceProviderList
    
    init(serviceProviderList: GetServiceProviderList) {
        self.serviceProviderList = serviceProviderList
    }
}

extension ServiceProviderListPresenter: ServiceProviderListPresenterContract {
    func viewLoaded() {
        let request = GetServiceProviderListRequest()
        serviceProviderList.execute(request: request, onSuccess: { [weak self] (response) in
            self?.result(serviceProviderList: response.serviceProvider)
        }, onFailure: { [weak self] (error) in
            self?.failed(error: error)
        })
        
        while serviceProviderList.response == nil && serviceProviderList.error == nil {
            
        }
        if let response = serviceProviderList.response {
            view?.load(serviceProviderList: response.serviceProvider)
        }
        else if let error = serviceProviderList.error {
            view?.failure(error: error)
        }
    }
}

extension ServiceProviderListPresenter {
    func result(serviceProviderList: [ServiceProvider]) {
        view?.load(serviceProviderList: serviceProviderList)
    }
    
    func failed(error: GetServiceProviderListError) {
        view?.failure(error: error)
    }
}
