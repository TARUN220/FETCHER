//
//  AddServiceProviderPresenter.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 02/03/23.
//

import Foundation
import FetcherBackEnd

class AddServiceProviderPresenter {
    weak var view: AddServiceProviderViewContract?
    var addServiceProvider: AddServiceProvider
    weak var router: AddServiceProviderRouterContract?
    
    init(addServiceProvider: AddServiceProvider) {
        self.addServiceProvider = addServiceProvider
    }
}

extension AddServiceProviderPresenter: AddServiceProviderPresenterContract {
    func viewLoaded(serviceProvider: FetcherBackEnd.ServiceProvider) {
        let request = AddServiceProviderRequest(serviceProvider: serviceProvider)
        addServiceProvider.execute(request: request, onSuccess: {
            [weak self] (response) in
            self?.result()
        }, onFailure: { [weak self] (error) in
            self?.failed()
        })
        while addServiceProvider.response == nil {

        }
//        //sleep(5)
//
        if addServiceProvider.response != nil {
            print("%%sP")
            view?.load()
        }
        else {
            view?.failure()
        }
    }
}

extension AddServiceProviderPresenter {
    func result() {
        view?.load()
    }
    
    func failed() {
        view?.failure()
    }
}
