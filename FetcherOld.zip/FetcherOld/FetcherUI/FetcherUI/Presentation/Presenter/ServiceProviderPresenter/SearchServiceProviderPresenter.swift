//
//  SearchServiceProviderPresenter.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 03/03/23.
//

import Foundation
import FetcherBackEnd

class SearchServiceProviderPresenter {
    weak var view: SearchServiceProviderViewContract?
    var searchServiceProvider: SearchServiceProvider
    weak var router: SearchServiceProviderRouterContract?
    var serviceProvider: ServiceProvider?
    var flag = false
    init(searchServiceProvider: SearchServiceProvider) {
        self.searchServiceProvider = searchServiceProvider
    }
}

extension SearchServiceProviderPresenter: SearchServiceProviderPresenterContract {
    func viewLoaded(columnName: String, columnValue: Any) {
        let request = SearchServiceProviderRequest(columnName: columnName, columnType: columnValue)
        searchServiceProvider.execute(request: request, onSuccess: { [weak self] (response) in
            self?.result(serviceProvider: response.serviceProvider)
        }, onFailure: { [weak self] (error) in
            self?.failure(error: error)
        })
        while searchServiceProvider.searchServiceProviderResponse == nil && searchServiceProvider.searchServiceProviderError == nil {
            sleep(1)
        }
        if let error = searchServiceProvider.searchServiceProviderError {
            view?.failure(error: error)
        }
        if let serviceProvider = searchServiceProvider.searchServiceProviderResponse?.serviceProvider {
            view?.load(serviceProvider: serviceProvider, flag: &flag)
        }
    }
    }

extension SearchServiceProviderPresenter {
    func result(serviceProvider: [ServiceProvider]) {
        view?.load(serviceProvider: serviceProvider, flag: &flag)
    }
    
    func failure(error: SearchServiceProviderError) {
        view?.failure(error: error)
    }
}
