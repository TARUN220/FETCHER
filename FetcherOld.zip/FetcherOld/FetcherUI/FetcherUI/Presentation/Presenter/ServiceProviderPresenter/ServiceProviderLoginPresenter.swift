//
//  ServiceProviderLoginPresenter.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 03/03/23.
//

import Foundation
import FetcherBackEnd

class ServiceProviderLoginPresenter {
    var view: ServiceProviderLoginViewContract?
    var searchServiceProvider: SearchServiceProvider
    weak var router: ServiceProviderLoginRouterContract?
    var isLogged: Bool?
    var emailId: String
    var password: String
    var role: ServiceProviderRole
    var serviceProvider: ServiceProvider?
    init(searchServiceProvider: SearchServiceProvider, emailId: String, password: String, role: ServiceProviderRole) {
        self.searchServiceProvider = searchServiceProvider
        self.emailId = emailId
        self.password = password
        self.role = role
    }
}

extension ServiceProviderLoginPresenter: ServiceProviderLoginPresenterContract {
    func viewLoaded(columnName: String, columnValue: Any) {
        let request = SearchServiceProviderRequest(columnName: columnName, columnType: columnValue)
        searchServiceProvider.execute(request: request, onSuccess: { [weak self] (response) in
            self?.success(serviceProvider: response.serviceProvider)
        }, onFailure: { [weak self] (error) in
            self?.failure()
        })

        while self.serviceProvider == nil && searchServiceProvider.searchServiceProviderError == nil {
            self.serviceProvider = searchServiceProvider.searchServiceProviderResponse?.serviceProvider[0]
        }

//        if searchServiceProvider.searchServiceProviderError != nil {
//            view?.invalidEmailId()
//            return
//        }

        if emailId != self.serviceProvider?.emailId {
            view?.invalidEmailId()
            return
        }
        else if password != self.serviceProvider?.password {
            view?.invalidPassword()
            return
        }
        else if role.role != self.serviceProvider?.role.role {
            view?.invalidRole()
        }
        else if password == self.serviceProvider?.password {
            isLogged = true
            view?.loginSuccess()
            return
        }
        

    }
}

extension ServiceProviderLoginPresenter {
    func success(serviceProvider: [ServiceProvider]) {
        isLogged = true
    }

    func failure() {
        isLogged = false
    }
}
