//
//  UpdateServiceProviderPresenter.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 14/03/23.
//

import Foundation
import FetcherBackEnd

class UpdateServiceProviderPresenter {
    
    weak var view: UpdateServiceProviderViewContract?
    var updateServiceProvider : UpdateServiceProvider
    weak var router: UpdateServiceProviderRouterContract?
    
    init(updateServiceProvider: UpdateServiceProvider) {
        self.updateServiceProvider = updateServiceProvider
    }
}

extension UpdateServiceProviderPresenter: UpdateServiceProviderPresenterContract {
    
    func viewLoaded(newValues: [String: Any], serviceProviderId: Int) {
        let request = UpdateServiceProviderRequest(newValues: newValues, serviceProviderId: serviceProviderId)
        updateServiceProvider.execute(request: request, onSuccess: { [weak self] (response) in
            self?.result()
        }, onFailure: { [weak self] (error) in
            print("Failure")
            self?.failed(error: error)
        })
    }
}

extension UpdateServiceProviderPresenter {
    
    func result() {
        //For UI
        view?.load()
    }
    
    func failed(error: UpdateServiceProviderError) {
        //For UI
        print("Error: ", error)
    }
}

