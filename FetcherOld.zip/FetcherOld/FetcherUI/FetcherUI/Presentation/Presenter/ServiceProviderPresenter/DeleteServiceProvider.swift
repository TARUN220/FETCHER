//
//  DeleteServiceProvider.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 13/03/23.
//

import Foundation
import FetcherBackEnd

class DeleteServiceProviderPresenter {
    
    weak var view: DeleteServiceProviderViewContract?
    var deleteServiceProvider: DeleteServiceProvider
    weak var router: DeleteServiceProviderRouterContract?
    
    init(deleteServiceProvider: DeleteServiceProvider) {
        self.deleteServiceProvider = deleteServiceProvider
    }
}

extension DeleteServiceProviderPresenter: DeleteServiceProviderPresenterContract {
    
    func viewLoaded(serviceProviderId: Int) {
        let request = DeleteServiceProviderRequest(serviceProviderId: serviceProviderId)
        deleteServiceProvider.execute(request: request, onSuccess: { [weak self] (response) in
            self?.result()
        }, onFailure: { [weak self] (error) in
            self?.failed(error: error)
        })
    }
}

extension DeleteServiceProviderPresenter {
    
    func result() {
        view?.load()
    }
    
    func failed(error: DeleteServiceProviderError) {
        view?.failure(error: error)
    }
}
