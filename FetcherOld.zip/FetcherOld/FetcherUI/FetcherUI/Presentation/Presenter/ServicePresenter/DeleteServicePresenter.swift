//
//  DeleteServicePresenter.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 13/03/23.
//

import Foundation
import FetcherBackEnd

class DeleteServicePresenter {
    
    weak var view: DeleteServiceViewContract?
    var deleteService: DeleteService
    weak var router: DeleteServiceRouterContract?
    
    init(deleteService: DeleteService) {
        self.deleteService = deleteService
    }
}

extension DeleteServicePresenter: DeleteServicePresenterContract {
    
    func viewLoaded(columnName: String, columnValue: Any) {
        let request = DeleteServiceRequest(columnName: columnName, columnValue: columnValue)
        deleteService.execute(request: request, onSuccess: { [weak self] (response) in
            self?.result()
        }, onFailure: { [weak self] (error) in
            self?.failed(error: error)
        })
        
        while deleteService.response == nil && deleteService.error == nil {
            
        }
        if let response = deleteService.response {
            view?.load()
        }
        else if let error = deleteService.error {
//            view?.failure()
            print("Error")
        }
    }
}

extension DeleteServicePresenter {
    
    func result() {
        view?.load()
    }
    
    func failed(error: DeleteServiceError) {
        view?.failure(error: error)
    }
}
