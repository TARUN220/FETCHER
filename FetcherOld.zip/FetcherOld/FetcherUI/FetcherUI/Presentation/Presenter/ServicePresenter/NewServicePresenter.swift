//
//  NewServicePresenter'.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 08/03/23.
//

import Foundation
import FetcherBackEnd

class NewServicePresenter {
    weak var view: NewServiceViewContract?
    var newService: NewService
    weak var router: NewServiceRouterContract?
    
    init(newService: NewService) {
        self.newService = newService
    }
}

extension NewServicePresenter: NewServicePresenterContract {
    func viewLoaded(service: FetcherBackEnd.Service) {
        let request = NewServiceRequest(service: service)
        newService.execute(request: request, onSuccess: {
            [weak self] (response) in
            self?.result()
        }, onFailure: { [weak self] (error) in
            self?.failed()
        })
        while newService.response == nil {

        }
//        //sleep(5)
//
//        if newService.response != nil {
//            print("%%sP")
//            view?.serviceSuccess()
//        }
//        else {
//            view?.failure()
//        }
        
        if newService.response != nil {
            print("S0")
            print(view)
            view?.serviceBooked()
        }
        else {
            print("S*-1")
            view?.serviceRejected()
        }
    }
}

extension NewServicePresenter {
    func result() {
        print("sR")
        view?.serviceSuccess()
    }
    
    func failed() {
        print("sF")
        view?.serviceRejected()
    }
}
