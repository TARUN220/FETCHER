//
//  UpdateServicePresenter.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 09/03/23.
//

import Foundation
import FetcherBackEnd

class UpdateServicePresenter {
    
    weak var view: UpdateServiceViewContract?
    var updateService: UpdateService
    weak var router: UpdateServiceRouterContract?
    
    init(updateService: UpdateService) {
        self.updateService = updateService
    }
}

extension UpdateServicePresenter: UpdateServicePresenterContract {
    
    func viewLoaded(newValues: [String: Any], serviceId: Int) {
        let request = UpdateServiceRequest(newValues: newValues, serviceId: serviceId)
        updateService.execute(request: request, onSuccess: { [weak self] (response) in
            self?.result()
        }, onFailure: { [weak self] (error) in
            self?.failed(error: error)
        })
        
        while updateService.response == nil && updateService.error == nil {
            
        }
        if let response = updateService.response {
            view?.load()
        }
        else if let error = updateService.error {
//            view?.failure()
            print("Error")
        }
    }
}

extension UpdateServicePresenter {
    
    func result() {
        view?.load()
    }
    
    func failed(error: UpdateServiceError) {
        
    }
}

