//
//  SearchServicePresenter.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 09/03/23.
//

import Foundation
import FetcherBackEnd

class SearchServicePresenter {
    weak var view: SearchServiceViewContract?
    var searchService: SearchService
    weak var router: SearchServiceRouterContract?
    var service: Service?
    var flag = false
    var id = 0
    init(searchService: SearchService) {
        self.searchService = searchService
    }
}

extension SearchServicePresenter: SearchServicePresenterContract {
    func viewLoaded(columnName: String, columnValue: Any) {
        let request = SearchServiceRequest(columnName: columnName, columnType: columnValue)
        searchService.execute(request: request, onSuccess: { [weak self] (response) in
            self?.result(service: response.service)
        }, onFailure: { [weak self] (error) in
            self?.failure(error: error)
        })
        while searchService.searchServiceResponse == nil && searchService.searchServiceError == nil {
            sleep(1)
        }
        if let error = searchService.searchServiceError {
            view?.failure(error: error)
        }
        if let service = searchService.searchServiceResponse?.service {
            view?.load(service: service, flag: &flag, id: &id)
        }
    }
    }

extension SearchServicePresenter {
    func result(service: [Service]) {
        view?.load(service: service, flag: &flag, id: &id)
    }
    
    func failure(error: SearchServiceError) {
        view?.failure(error: error)
    }
}
