//
//  ServiceRequestListPresenter.swift
//  FetcherUI
//
//  Created by tarun-pt6229 on 08/03/23.
//

import Foundation
import FetcherBackEnd

class ServiceRequestListPresenter {
    weak var view: ServiceRequestListViewContract?
    weak var router: ServiceRequestListRouterContract?
    var serviceRequestList: GetServiceRequestList
    
    init(serviceRequestList: GetServiceRequestList) {
        self.serviceRequestList = serviceRequestList
    }
}

extension ServiceRequestListPresenter: ServiceRequestListPresenterContract {
    func viewLoaded(columnName: String, columnValue: Any) {
        let request = GetServiceRequestListRequest(columnName: columnName, columnType: columnValue)
        serviceRequestList.execute(request: request, onSuccess: { [weak self] (response) in
            self?.result(service: response.service)
        }, onFailure: { [weak self] (error) in
            self?.failed(error: error)
        })
        
        while serviceRequestList.response == nil && serviceRequestList.error == nil {
            
        }
        if let response = serviceRequestList.response {
            print("c0")
            view?.load(serviceRequestList: response.service)
        }
        else if let error = serviceRequestList.error {
            print("c-0")
            view?.failure(error: error)
        }
    }
    
//    func viewLoaded() {
//
//    }
}

extension ServiceRequestListPresenter {
    func result(service: [Service]) {
        print("cc0")
        view?.load(serviceRequestList: service)
    }
    
    func failed(error: GetServiceRequestListError) {
        print("cc-0")
        view?.failure(error: error)
    }
}
